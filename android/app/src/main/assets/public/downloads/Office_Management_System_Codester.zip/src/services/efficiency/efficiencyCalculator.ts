import { TaskRecord, getEffectiveTaskStatus } from '../../types/planner';
import { AttendanceRecord } from '../../types/attendance';
import { DailyWorkDetailRecord } from '../../types/workDetails';
import { 
  EfficiencyBreakdown, 
  EfficiencyGrade, 
  EfficiencyWeightages, 
  getEfficiencyGrade 
} from '../../types/efficiency';

/**
 * Checks if a formatted time string (e.g. "10:31 AM") is late (10:31 AM or later / after 10:30 AM).
 * Official Office Start Time: 10:00 AM
 * Grace Period / Not Late: 10:01 AM - 10:30 AM
 * Late Threshold: 10:31 AM or later
 */
export const isLateCheckIn = (checkInTimeStr: string): boolean => {
  if (!checkInTimeStr) return false;
  try {
    const trimmed = checkInTimeStr.trim().toUpperCase();
    const parts = trimmed.split(' ');
    if (parts.length < 2) return false;
    const timePart = parts[0];
    const modifier = parts[1]; // AM or PM
    let [hours, minutes] = timePart.split(':').map(Number);
    if (modifier === 'PM' && hours < 12) hours += 12;
    if (modifier === 'AM' && hours === 12) hours = 0;
    
    // threshold: 10:30 AM -> 10 hours 30 mins = 630 mins
    // 10:31 AM or later is > 630 mins
    const minutesSinceMidnight = hours * 60 + minutes;
    const thresholdMinutes = 10 * 60 + 30;
    return minutesSinceMidnight > thresholdMinutes;
  } catch (err) {
    return false;
  }
};

/**
 * Calculates weekdays (Mon-Fri) in YYYY-MM-DD range, capping at today to avoid future planning skew.
 */
export const calculateExpectedWorkingDays = (startDateStr: string, endDateStr: string): number => {
  try {
    const start = new Date(startDateStr);
    const end = new Date(endDateStr);
    const today = new Date();
    
    // Cap at today so we don't penalize for future days of the week/month
    const limitDate = end < today ? end : today;
    
    if (start > limitDate) return 0;
    
    let count = 0;
    const cur = new Date(start);
    while (cur <= limitDate) {
      const day = cur.getDay();
      if (day !== 0 && day !== 6) { // Not Sunday (0) or Saturday (6)
        count++;
      }
      cur.setDate(cur.getDate() + 1);
    }
    return count || 1; // Default to 1 to prevent division by zero
  } catch (err) {
    return 1;
  }
};

let calcInvocationCount = 0;

/**
 * Pure function to calculate efficiency breakdown and final score.
 */
export const calculateEfficiency = (
  employeeId: string,
  employeeCode: string,
  employeeName: string,
  department: string,
  teamLeaderId: string | null,
  startDateStr: string,
  endDateStr: string,
  tasks: TaskRecord[],
  attendanceRecords: AttendanceRecord[],
  weightages: EfficiencyWeightages,
  workDetails: DailyWorkDetailRecord[] = []
): { finalScore: number; grade: EfficiencyGrade; breakdown: EfficiencyBreakdown } => {
  calcInvocationCount++;
  const calcId = calcInvocationCount;
  const startTime = performance.now();

  console.log(`[EFFICIENCY_CALC_START] #${calcId} for employee=${employeeCode || employeeId} (${employeeName}) period=${startDateStr}..${endDateStr} inputTasks=${tasks.length} inputAtt=${attendanceRecords.length} inputWorkDetails=${(workDetails || []).length}`);
  
  // ----------------------------------------------------
  // 1. FILTER RELEVANT RECORDS FOR THE PERIOD
  // ----------------------------------------------------
  
  // Filter attendance records in period
  const periodAttendance = attendanceRecords.filter(rec => {
    const rId = String(rec.employeeId || '').trim().toUpperCase();
    const rCode = String(rec.employeeCode || '').trim().toUpperCase();
    const tId = String(employeeId || '').trim().toUpperCase();
    const tCode = String(employeeCode || '').trim().toUpperCase();

    const matchId = rId && (rId === tCode || (tId && rId === tId));
    const matchCode = rCode && (rCode === tCode || (tId && rCode === tId));
    const isEmp = matchId || matchCode;
    return isEmp && rec.date >= startDateStr && rec.date <= endDateStr;
  });

  // Filter daily work details in period
  const periodWorkDetails = (workDetails || []).filter(wd => {
    const wId = String(wd.employeeId || '').trim().toUpperCase();
    const wCode = String(wd.employeeCode || '').trim().toUpperCase();
    const tId = String(employeeId || '').trim().toUpperCase();
    const tCode = String(employeeCode || '').trim().toUpperCase();

    const matchId = wId && (wId === tCode || (tId && wId === tId));
    const matchCode = wCode && (wCode === tCode || (tId && wCode === tId));
    const isEmp = matchId || matchCode;
    return isEmp && wd.date >= startDateStr && wd.date <= endDateStr;
  });

  // Meaningful validation for daily work details: reject empty, single-word or repeated gibberish
  const validWorkDetails = periodWorkDetails.filter(wd => {
    const text = (wd.workDetails || '').trim();
    if (text.length < 15) return false;
    const alphanumeric = text.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (alphanumeric.length < 10) return false;
    const uniqueChars = new Set(alphanumeric).size;
    return uniqueChars >= 4;
  });

  // Filter tasks in period
  const periodTasks = tasks.filter(task => {
    const tId = String(employeeId || '').trim().toUpperCase();
    const tCode = String(employeeCode || '').trim().toUpperCase();

    const assignedCodes = Array.isArray(task.assignedToEmployeeCodes) 
      ? task.assignedToEmployeeCodes.map(c => String(c).trim().toUpperCase()) 
      : [];
    const assignedIds = Array.isArray(task.assignedToEmployeeIds) 
      ? task.assignedToEmployeeIds.map(i => String(i).trim().toUpperCase()) 
      : [];
    
    const creatorId = String(task.createdBy || '').trim().toUpperCase();
    const assigneeCode = String((task as any).assigneeCode || '').trim().toUpperCase();
    const assigneeId = String((task as any).assigneeId || '').trim().toUpperCase();
    const assignedTo = String((task as any).assignedTo || '').trim().toUpperCase();
    const empCodeField = String((task as any).employeeCode || '').trim().toUpperCase();

    const isAssigned = (tCode && assignedCodes.includes(tCode)) || 
                       (tId && assignedCodes.includes(tId)) || 
                       (tCode && assignedIds.includes(tCode)) || 
                       (tId && assignedIds.includes(tId)) ||
                       (tCode && creatorId === tCode) ||
                       (tId && creatorId === tId) ||
                       (tCode && assigneeCode === tCode) ||
                       (tId && assigneeCode === tId) ||
                       (tCode && assigneeId === tCode) ||
                       (tId && assigneeId === tId) ||
                       (tCode && assignedTo === tCode) ||
                       (tId && assignedTo === tId) ||
                       (tCode && empCodeField === tCode) ||
                       (tId && empCodeField === tId);
    
    if (!isAssigned) return false;
    
    // Task date is either due date or completed date
    const taskDate = task.dueDate || (task.completedAt ? task.completedAt.substring(0, 10) : task.createdAtDeviceTime ? task.createdAtDeviceTime.substring(0, 10) : '');
    return taskDate >= startDateStr && taskDate <= endDateStr;
  });

  // Deduplicate tasks by ID to prevent inflation
  const dedupedTasksMap = new Map<string, TaskRecord>();
  periodTasks.forEach(t => {
    if (t.id) dedupedTasksMap.set(t.id, t);
  });
  const uniqueTasks = Array.from(dedupedTasksMap.values());

  // Filter out cancelled status if any exists
  const validTasks = uniqueTasks.filter(t => {
    const s = (t.status || '').toUpperCase().trim();
    return s !== 'CANCELLED' && s !== 'CANCEL';
  });

  const isCompletedTask = (t: TaskRecord): boolean => {
    const s = (t.status || '').toUpperCase().trim();
    return s === 'COMPLETED' || t.approvalStatus === 'APPROVED' || getEffectiveTaskStatus(t) === 'Completed';
  };

  const isOverdueTask = (t: TaskRecord): boolean => {
    return getEffectiveTaskStatus(t) === 'Overdue';
  };

  // ----------------------------------------------------
  // 2. TASK COMPLETION SCORE
  // ----------------------------------------------------
  const assignedTasksCount = validTasks.length;
  const completedTasksCount = validTasks.filter(isCompletedTask).length;
  
  const taskCompletionScore = assignedTasksCount > 0 
    ? Math.round((completedTasksCount / assignedTasksCount) * 100) 
    : -1; // NO DATA

  // ----------------------------------------------------
  // 3. ON-TIME COMPLETION SCORE
  // ----------------------------------------------------
  const completedTasks = validTasks.filter(isCompletedTask);
  
  let onTimeTasksCount = 0;
  completedTasks.forEach(task => {
    if (task.completedAt && task.dueDate) {
      const completedDateOnly = task.completedAt.substring(0, 10);
      if (completedDateOnly <= task.dueDate) {
        onTimeTasksCount++;
      }
    } else {
      // Fallback: check if effective status is not Overdue
      const effective = getEffectiveTaskStatus(task);
      if (effective === 'Completed') {
        onTimeTasksCount++;
      }
    }
  });

  const onTimeCompletionScore = completedTasksCount > 0
    ? Math.round((onTimeTasksCount / completedTasksCount) * 100)
    : -1; // NO DATA (Neutral state handled safely)

  // ----------------------------------------------------
  // 4. QUALITY / APPROVAL SCORE
  // ----------------------------------------------------
  // Filter completed tasks that have been reviewed (APPROVED or REVISION_REQUIRED / Revision Requested)
  const reviewedTasks = completedTasks.filter(t => 
    t.approvalStatus === 'APPROVED' || 
    t.approvalStatus === 'REVISION_REQUIRED' ||
    (t.revisions && t.revisions.length > 0)
  );
  
  const approvedTasksCount = completedTasks.filter(t => t.approvalStatus === 'APPROVED' || (!t.revisionCount && (!t.revisions || t.revisions.length === 0))).length;
  const revisionRequiredTasksCount = completedTasks.filter(t => t.approvalStatus === 'REVISION_REQUIRED' || (t.revisions && t.revisions.length > 0)).length;
  const totalRevisionRequests = completedTasks.reduce((sum, t) => sum + (t.revisionCount || t.revisions?.length || 0), 0);

  let qualityScore = -1; // Default to NO DATA
  
  if (completedTasksCount > 0) {
    if (reviewedTasks.length > 0) {
      const baseRatioScore = (approvedTasksCount / reviewedTasks.length) * 100;
      
      // Calculate progressive penalty for repeated revisions on each task
      let progressiveRevPenalty = 0;
      completedTasks.forEach(task => {
        const revs = task.revisionCount || task.revisions?.length || 0;
        if (revs === 1) {
          progressiveRevPenalty += 10;
        } else if (revs === 2) {
          progressiveRevPenalty += 25;
        } else if (revs >= 3) {
          progressiveRevPenalty += 50;
        }
      });
      
      // Normalize penalty across completed tasks
      const normalizedRevPenalty = progressiveRevPenalty / completedTasksCount;
      qualityScore = Math.max(0, Math.min(100, Math.round(baseRatioScore - normalizedRevPenalty)));
    } else {
      // If completed tasks exist but none are reviewed yet, give a neutral starting 100 points
      qualityScore = 100;
    }
  }

  // ----------------------------------------------------
  // 5. ATTENDANCE / PUNCTUALITY SCORE
  // ----------------------------------------------------
  const expectedWorkingDays = calculateExpectedWorkingDays(startDateStr, endDateStr);
  const attendanceDaysCount = periodAttendance.length;
  
  const validCheckInsCount = periodAttendance.filter(rec => rec.checkInTime).length;
  const validCheckOutsCount = periodAttendance.filter(rec => 
    rec.checkOutTime && 
    rec.checkOutTime !== 'N/A' && 
    rec.checkoutStatus !== 'UNRESOLVED' && 
    rec.checkoutStatus !== 'PENDING_ADMIN_REVIEW'
  ).length;
  const lateArrivalsCount = periodAttendance.filter(rec => {
    return isLateCheckIn(rec.checkInTime);
  }).length;

  let punctualityScore = -1; // Default to NO DATA
  
  if (attendanceDaysCount > 0) {
    const attendanceRate = Math.min(1, attendanceDaysCount / expectedWorkingDays);
    const onTimeCheckIns = attendanceDaysCount - lateArrivalsCount;
    const punctualityRatio = onTimeCheckIns / attendanceDaysCount;
    const checkoutRatio = validCheckOutsCount / attendanceDaysCount;
    
    // Punctuality Score composite:
    // 50% punctuality ratio, 30% attendance rate, 20% checkout logging compliance
    punctualityScore = Math.round(
      (punctualityRatio * 0.5 + attendanceRate * 0.3 + checkoutRatio * 0.2) * 100
    );
    punctualityScore = Math.max(0, Math.min(100, punctualityScore));
  }

  // ----------------------------------------------------
  // 6. WORKLOAD SCORE
  // ----------------------------------------------------
  let workloadScore = -1; // Default to NO DATA
  const overdueTasksCount = validTasks.filter(isOverdueTask).length;

  if (assignedTasksCount > 0) {
    // Average completion percentage of non-completed (active) tasks
    const activeTasks = validTasks.filter(t => !isCompletedTask(t));
    const activeCompletionSum = activeTasks.reduce((sum, t) => sum + (t.completionPercentage || 0), 0);
    const averageActiveCompletion = activeTasks.length > 0 ? activeCompletionSum / activeTasks.length : 0;
    
    // Normalized base: completed percentage of workload + partial progress on active
    const completedWeight = completedTasksCount / assignedTasksCount;
    const activeWeight = (activeTasks.length * (averageActiveCompletion / 100)) / assignedTasksCount;
    let workloadBase = (completedWeight + activeWeight) * 100;
    
    // If valid daily work details were submitted, reinforce documented daily activity (+10 boost, capped at 100)
    if (validWorkDetails.length > 0) {
      workloadBase = Math.min(100, workloadBase + 10);
    }

    // Penalty for active overdue tasks in workload
    const workloadOverduePenalty = overdueTasksCount * 15;
    
    workloadScore = Math.max(0, Math.min(100, Math.round(workloadBase - workloadOverduePenalty)));
  } else if (validWorkDetails.length > 0) {
    // When no formal planner tasks were assigned, but the employee documented legitimate operational duties
    // Establish a solid baseline workload fulfillment (80 base score, representing documented daily activity)
    workloadScore = 80;
  }

  // ----------------------------------------------------
  // 7. PENALTIES (Controlled non-linear)
  // ----------------------------------------------------
  // Overdue Penalty: 1st task = 3pts, 2nd task = 7pts, 3+ tasks = 10pts
  let overduePenalty = 0;
  if (overdueTasksCount === 1) {
    overduePenalty = 3;
  } else if (overdueTasksCount === 2) {
    overduePenalty = 7;
  } else if (overdueTasksCount >= 3) {
    overduePenalty = 10;
  }

  // Revision Penalty: 1st = 2pts, 2nd = 5pts, 3rd = 8pts, 4+ = 10pts
  let revisionPenalty = 0;
  if (totalRevisionRequests === 1) {
    revisionPenalty = 2;
  } else if (totalRevisionRequests === 2) {
    revisionPenalty = 5;
  } else if (totalRevisionRequests === 3) {
    revisionPenalty = 8;
  } else if (totalRevisionRequests >= 4) {
    revisionPenalty = 10;
  }

  // ----------------------------------------------------
  // 8. FINAL SCORE & NORMALIZATION
  // ----------------------------------------------------
  const scores = [
    { score: taskCompletionScore, weight: weightages.taskCompletion },
    { score: onTimeCompletionScore, weight: weightages.onTimeCompletion },
    { score: qualityScore, weight: weightages.quality },
    { score: punctualityScore, weight: weightages.punctuality },
    { score: workloadScore, weight: weightages.workload }
  ];

  let sumOfAvailableWeights = 0;
  let weightedScoreSum = 0;

  scores.forEach(s => {
    if (s.score !== -1) {
      sumOfAvailableWeights += s.weight;
      weightedScoreSum += s.score * s.weight;
    }
  });

  const weightedBaseScore = sumOfAvailableWeights > 0
    ? weightedScoreSum / sumOfAvailableWeights
    : 0;

  // Final Score = Weighted Base - Overdue Penalty - Revision Penalty
  const calculatedFinalScore = sumOfAvailableWeights > 0
    ? Math.max(0, Math.min(100, Math.round(weightedBaseScore - overduePenalty - revisionPenalty)))
    : -1;

  const finalScore = calculatedFinalScore;
  const grade = finalScore < 0 ? ('N/A' as EfficiencyGrade) : getEfficiencyGrade(finalScore);

  const breakdown: EfficiencyBreakdown = {
    taskCompletionScore,
    onTimeCompletionScore,
    qualityScore,
    punctualityScore,
    workloadScore,
    
    assignedTasksCount,
    completedTasksCount,
    onTimeTasksCount,
    approvedTasksCount,
    revisionRequiredTasksCount,
    totalRevisionRequests,
    
    attendanceDaysCount,
    lateArrivalsCount,
    validCheckInsCount,
    validCheckOutsCount,
    
    overdueTasksCount,
    overduePenalty,
    revisionPenalty,

    workDetailsSubmitted: validWorkDetails.length > 0,
    workDetailsCount: validWorkDetails.length
  };

  const durationMs = Math.round((performance.now() - startTime) * 100) / 100;
  console.log(`[EFFICIENCY_DIAGNOSTIC] empCode=${employeeCode || employeeId} targetDate=${startDateStr} attendanceFound=${attendanceDaysCount > 0} taskCount=${assignedTasksCount} completedTaskCount=${completedTasksCount} taskCompletionScore=${taskCompletionScore} onTimeCompletionScore=${onTimeCompletionScore} qualityScore=${qualityScore} punctualityScore=${punctualityScore} workloadScore=${workloadScore} overduePenalty=${overduePenalty} revisionPenalty=${revisionPenalty} sumOfAvailableWeights=${sumOfAvailableWeights} weightedScoreSum=${weightedScoreSum} weightedBaseScore=${weightedBaseScore} finalScore=${finalScore}`);
  console.log(`[EFFICIENCY_CALC_END] #${calcId} employee=${employeeCode || employeeId} finalScore=${finalScore}% grade=${grade} elapsedMs=${durationMs}ms (totalCalculationsTotal=${calcInvocationCount})`);

  return {
    finalScore,
    grade,
    breakdown
  };
};
