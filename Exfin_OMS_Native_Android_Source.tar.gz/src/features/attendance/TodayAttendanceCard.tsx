import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { 
  CheckCircle2, 
  Clock, 
  Home, 
  MapPin, 
  Briefcase, 
  Activity,
  AlertCircle
} from 'lucide-react';
import { AttendanceRecord, LiveEmployeeLocation } from '../../types/attendance';
import { Card } from '../../components/ui/Card';
import { calculateWorkingHours, parseAttendanceTimeToMinutes } from '../../services/attendance/smartAttendanceEngine';

interface TodayAttendanceCardProps {
  todayRecord: AttendanceRecord | null;
  isSyncing?: boolean;
  isOnline?: boolean;
  liveLocationData?: LiveEmployeeLocation | null;
}

const formatDuration = (seconds: number): string => {
  if (seconds <= 0) return '0m';
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor((seconds % 3600) / 60);

  if (hrs > 0) {
    return `${hrs}h ${mins}m`;
  }
  return `${mins}m`;
};

export const TodayAttendanceCard: React.FC<TodayAttendanceCardProps> = ({
  todayRecord,
  isSyncing = false,
  isOnline = true,
  liveLocationData = null
}) => {
  const [now, setNow] = useState<Date>(new Date());

  useEffect(() => {
    if (todayRecord && todayRecord.checkInTime && !todayRecord.checkOutTime) {
      let timer: NodeJS.Timeout | null = null;

      const startTimer = () => {
        if (!timer) {
          setNow(new Date());
          timer = setInterval(() => {
            setNow(new Date());
          }, 15000);
        }
      };

      const stopTimer = () => {
        if (timer) {
          clearInterval(timer);
          timer = null;
        }
      };

      if (document.visibilityState === 'visible') {
        startTimer();
      }

      const handleVisibility = () => {
        if (document.visibilityState === 'visible') {
          startTimer();
        } else {
          stopTimer();
        }
      };

      document.addEventListener('visibilitychange', handleVisibility);

      return () => {
        stopTimer();
        document.removeEventListener('visibilitychange', handleVisibility);
      };
    }
  }, [todayRecord?.checkInTime, todayRecord?.checkOutTime]);

  const isCheckedIn = !!todayRecord && !!todayRecord.checkInTime && todayRecord.checkInTime !== '--:--';
  const isCheckedOut = !!todayRecord && !!todayRecord.checkOutTime && todayRecord.checkOutTime !== '--:--';
  const attendanceType = todayRecord?.attendanceType || 'OFFICE';

  let workingTimeStr = '--';

  if (isCheckedIn && todayRecord?.checkInTime) {
    if (isCheckedOut && todayRecord.checkOutTime) {
      const calculated = calculateWorkingHours(todayRecord.checkInTime, todayRecord.checkOutTime);
      workingTimeStr = calculated || '--';
    } else {
      const checkInMins = parseAttendanceTimeToMinutes(todayRecord.checkInTime);
      if (checkInMins !== null) {
        const nowMins = now.getHours() * 60 + now.getMinutes();
        const nowSecs = now.getSeconds();
        const totalElapsedSecs = Math.max(0, (nowMins - checkInMins) * 60 + nowSecs);
        workingTimeStr = formatDuration(totalElapsedSecs);
      }
    }
  }

  let statusTitle = 'NOT CHECKED IN';
  let statusBadgeText = 'Not Started';
  let statusBorderColor = 'border-[#2A5B50]';
  let badgeStyle = 'bg-[#112C26] text-[#C7DAD3] border-[#2A5B50]';
  let StateIcon = Clock;

  if (isCheckedOut) {
    statusTitle = 'CHECKED OUT';
    statusBadgeText = 'Workday Completed';
    statusBorderColor = 'border-[#35C98A]/40';
    badgeStyle = 'bg-[#35C98A]/20 text-[#35C98A] border-[#35C98A]/40';
    StateIcon = CheckCircle2;
  } else if (isCheckedIn) {
    if (attendanceType === 'WFH') {
      statusTitle = 'WORK FROM HOME';
      statusBadgeText = 'WFH Active';
      statusBorderColor = 'border-[#19C7C0]/40';
      badgeStyle = 'bg-[#19C7C0]/20 text-[#19C7C0] border-[#19C7C0]/40';
      StateIcon = Home;
    } else if (attendanceType === 'CLIENT_VISIT') {
      statusTitle = 'CLIENT VISIT';
      statusBadgeText = todayRecord.clientName ? `Client: ${todayRecord.clientName}` : 'On-Site Visit';
      statusBorderColor = 'border-[#19C7C0]/40';
      badgeStyle = 'bg-[#19C7C0]/20 text-[#19C7C0] border-[#19C7C0]/40';
      StateIcon = MapPin;
    } else if (attendanceType === 'OUTDOOR') {
      statusTitle = 'OUTDOOR WORK';
      statusBadgeText = todayRecord.outdoorType || 'Field Duty';
      statusBorderColor = 'border-[#F2C75C]/40';
      badgeStyle = 'bg-[#F2C75C]/20 text-[#F2C75C] border-[#F2C75C]/40';
      StateIcon = Briefcase;
    } else {
      statusTitle = 'PRESENT';
      statusBadgeText = todayRecord.checkInMode === 'AUTO' ? 'Auto Check-In' : 'Office Attendance';
      statusBorderColor = 'border-[#35C98A]/40';
      badgeStyle = 'bg-[#35C98A]/20 text-[#35C98A] border-[#35C98A]/40';
      StateIcon = CheckCircle2;
    }
  }

  const todayDateFormatted = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  });

  return (
    <Card className={`p-4 sm:p-5 bg-[#173A32] border ${statusBorderColor} shadow-xl relative overflow-hidden transition-all duration-300 text-[#F4FAF7]`}>
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-[#19C7C0]/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header Row */}
      <div className="flex items-center justify-between pb-3 border-b border-[#2A5B50] mb-4">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-[#21483E] border border-[#2A5B50] flex items-center justify-center">
            <StateIcon className="w-4 h-4 text-[#19C7C0]" />
          </div>
          <div>
            <h2 className="text-xs font-black uppercase tracking-wider text-[#F4FAF7]">TODAY'S ATTENDANCE</h2>
            <p className="text-[10px] text-[#C7DAD3] font-medium">{todayDateFormatted}</p>
          </div>
        </div>

        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${badgeStyle} flex items-center gap-1.5`}>
          <span className="w-1.5 h-1.5 rounded-full bg-current animate-pulse" />
          {statusBadgeText}
        </span>
      </div>

      {/* Main Status Title & Details */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center mb-4">
        <div>
          <span className="text-[10px] font-bold text-[#9FB9AF] uppercase tracking-wider block mb-0.5">
            Current Status
          </span>

          <h1 className="text-2xl sm:text-3xl font-black text-[#F4FAF7] tracking-tight leading-none">
            {statusTitle}
          </h1>

          <div className="mt-2 text-xs font-medium text-[#C7DAD3]">
            {isCheckedOut ? (
              <span className="text-[#35C98A] font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" /> Checked in {todayRecord.checkInTime} — Checked out {todayRecord.checkOutTime}
              </span>
            ) : isCheckedIn ? (
              <span className="text-[#F4FAF7] flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-[#35C98A]" />
                Checked in at <strong className="text-[#35C98A] font-mono">{todayRecord.checkInTime}</strong>
              </span>
            ) : (
              <span className="text-[#9FB9AF]">
                Check-in not yet recorded today
              </span>
            )}
          </div>
        </div>

        {/* Working Time Badge */}
        <div className="bg-[#112C26] p-3.5 rounded-2xl border border-[#2A5B50] flex flex-col items-start sm:items-end justify-center">
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#19C7C0] flex items-center gap-1 mb-0.5">
            <Activity className="w-3.5 h-3.5 text-[#19C7C0]" />
            WORKING TIME
          </span>
          <span className="text-xl sm:text-2xl font-black font-mono text-[#F4FAF7] tracking-tight">
            {workingTimeStr}
          </span>
        </div>
      </div>

      {/* Check-In & Checkout Display Cards */}
      <div className="pt-3 border-t border-[#2A5B50]">
        <div className="grid grid-cols-2 gap-3">
          {/* Check-In Box */}
          <div className="bg-[#112C26] p-3 rounded-xl border border-[#2A5B50] space-y-1">
            <span className="text-[10px] font-black text-[#F4FAF7] uppercase tracking-wider block">
              CHECK-IN
            </span>
            <span className="text-base sm:text-lg font-black font-mono text-[#F4FAF7] block">
              {todayRecord?.checkInTime || 'Not recorded'}
            </span>
            <span className="text-[10px] text-[#C7DAD3] font-medium block truncate">
              {isCheckedIn ? (attendanceType === 'OFFICE' ? 'Office HQ' : attendanceType.replace('_', ' ')) : 'Awaiting check-in'}
            </span>
          </div>

          {/* Checkout Box */}
          <div className="bg-[#112C26] p-3 rounded-xl border border-[#2A5B50] space-y-1">
            <span className="text-[10px] font-black text-[#F4FAF7] uppercase tracking-wider block">
              CHECKOUT
            </span>
            <span className="text-base sm:text-lg font-black font-mono text-[#F4FAF7] block">
              {todayRecord?.checkOutTime || 'Not recorded'}
            </span>
            <span className="text-[10px] text-[#C7DAD3] font-medium block truncate">
              {isCheckedOut ? 'Checkout recorded' : isCheckedIn ? 'Session in progress' : 'Not recorded'}
            </span>
          </div>
        </div>
      </div>
    </Card>
  );
};

