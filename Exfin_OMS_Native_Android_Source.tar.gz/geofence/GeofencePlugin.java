package com.exfin.oms.geofence;

import android.content.Context;
import android.util.Log;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

@CapacitorPlugin(name = "ExfinGeofence")
public class GeofencePlugin extends Plugin {
    public static final String TAG = "GeofencePlugin";
    private static GeofencePlugin instance;

    @Override
    public void load() {
        super.load();
        instance = this;
    }

    public static void notifyNativeCheckIn(JSONObject event) {
        if (instance != null && event != null) {
            try {
                JSObject ret = JSObject.fromJSONObject(event);
                instance.notifyListeners("attendanceNativeCheckIn", ret, true);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying attendanceNativeCheckIn: " + e.getMessage());
            }
        }
    }

    public static void notifyNativeCheckOut(JSONObject event) {
        if (instance != null && event != null) {
            try {
                JSObject ret = JSObject.fromJSONObject(event);
                instance.notifyListeners("attendanceNativeCheckOut", ret, true);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying attendanceNativeCheckOut: " + e.getMessage());
            }
        }
    }

    public static void notifyNativeReturn(JSONObject event) {
        if (instance != null && event != null) {
            try {
                JSObject ret = JSObject.fromJSONObject(event);
                instance.notifyListeners("attendanceNativeReturn", ret, true);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying attendanceNativeReturn: " + e.getMessage());
            }
        }
    }

    public static void notifyNativeSync(String eventId, boolean success) {
        if (instance != null) {
            try {
                JSObject ret = new JSObject();
                ret.put("eventId", eventId);
                ret.put("success", success);
                ret.put("timestamp", System.currentTimeMillis());
                instance.notifyListeners("attendanceNativeSync", ret, true);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying attendanceNativeSync: " + e.getMessage());
            }
        }
    }

    public static void notifyNativeError(String error) {
        if (instance != null) {
            try {
                JSObject ret = new JSObject();
                ret.put("error", error);
                ret.put("timestamp", System.currentTimeMillis());
                instance.notifyListeners("attendanceNativeError", ret, true);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying attendanceNativeError: " + e.getMessage());
            }
        }
    }

    public static void notifyNativeTransition(String transition, double lat, double lng, long eventTimestamp) {
        if (instance != null) {
            try {
                Date eventDate = new Date(eventTimestamp);
                SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.US);
                sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
                String timeStr = sdf.format(eventDate);

                SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                sdfDate.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
                String dateStr = sdfDate.format(eventDate);

                JSObject ret = new JSObject();
                ret.put("transition", transition);
                ret.put("time", timeStr);
                ret.put("date", dateStr);
                if (!Double.isNaN(lat) && !Double.isInfinite(lat)) {
                    ret.put("latitude", lat);
                } else {
                    ret.put("latitude", (String) null);
                }
                if (!Double.isNaN(lng) && !Double.isInfinite(lng)) {
                    ret.put("longitude", lng);
                } else {
                    ret.put("longitude", (String) null);
                }
                ret.put("timestamp", eventTimestamp);
                ret.put("exitTimestamp", eventTimestamp);

                instance.notifyListeners("geofenceTransition", ret, true);
            } catch (Exception e) {
                Log.e(TAG, "Error notifying JS listeners: " + e.getMessage(), e);
            }
        }
    }

    @PluginMethod
    public void registerOfficeGeofence(PluginCall call) {
        try {
            Context context = getContext();
            OfficeGeofenceHelper.registerOfficeGeofence(context);

            JSObject ret = new JSObject();
            ret.put("success", true);
            ret.put("geofenceId", OfficeGeofenceHelper.GEOFENCE_ID);
            ret.put("authoritativeRadius", OfficeGeofenceHelper.AUTHORITATIVE_RADIUS_METERS);
            ret.put("wakeupTriggerRadius", OfficeGeofenceHelper.WAKEUP_TRIGGER_RADIUS_METERS);
            ret.put("assistRadius", OfficeGeofenceHelper.ASSIST_RADIUS_METERS);
            ret.put("latitude", OfficeGeofenceHelper.OFFICE_LAT);
            ret.put("longitude", OfficeGeofenceHelper.OFFICE_LNG);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to register office geofence: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void getGeofenceStatus(PluginCall call) {
        try {
            Context context = getContext();
            boolean isRegistered = OfficeGeofenceHelper.isGeofenceRegistered(context);

            JSObject ret = new JSObject();
            ret.put("isRegistered", isRegistered);
            ret.put("geofenceId", OfficeGeofenceHelper.GEOFENCE_ID);
            ret.put("authoritativeRadius", OfficeGeofenceHelper.AUTHORITATIVE_RADIUS_METERS);
            ret.put("wakeupTriggerRadius", OfficeGeofenceHelper.WAKEUP_TRIGGER_RADIUS_METERS);
            ret.put("assistRadius", OfficeGeofenceHelper.ASSIST_RADIUS_METERS);
            ret.put("latitude", OfficeGeofenceHelper.OFFICE_LAT);
            ret.put("longitude", OfficeGeofenceHelper.OFFICE_LNG);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to get geofence status: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void getUnconsumedNativeEvents(PluginCall call) {
        try {
            Context context = getContext();
            JSONArray events = OfficeGeofenceHelper.getAndClearUnconsumedEvents(context);

            JSObject ret = new JSObject();
            JSArray arr = new JSArray();
            for (int i = 0; i < events.length(); i++) {
                JSONObject obj = events.getJSONObject(i);
                JSObject item = JSObject.fromJSONObject(obj);
                arr.put(item);
            }
            ret.put("events", arr);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to retrieve unconsumed events: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void removeOfficeGeofence(PluginCall call) {
        try {
            Context context = getContext();
            OfficeGeofenceHelper.removeOfficeGeofence(context);

            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to remove office geofence: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void setEmployeeIdentity(PluginCall call) {
        try {
            Context context = getContext();
            String id = call.getString("id");
            String name = call.getString("name");
            String townCity = call.getString("townCity", "Raniganj HQ");
            String serverUrl = call.getString("serverUrl");

            if (id != null && !id.trim().isEmpty()) {
                android.content.SharedPreferences prefs = context.getSharedPreferences(OfficeGeofenceHelper.PREFS_NAME, Context.MODE_PRIVATE);
                android.content.SharedPreferences.Editor editor = prefs.edit();
                editor.putString("employee_id", id);
                editor.putString("employee_name", name);
                editor.putString("town_city", townCity);
                if (serverUrl != null && !serverUrl.trim().isEmpty()) {
                    editor.putString("server_url", serverUrl);
                }
                editor.apply();
                Log.i(TAG, "Native employee identity set: " + id + " (" + name + ") - Server URL: " + serverUrl);

                OfficeGeofenceHelper.registerNetworkCallbackIfNecessary(context);
                OfficeGeofenceHelper.triggerBackgroundSync(context);

                call.resolve();
            } else {
                call.reject("Invalid employee ID");
            }
        } catch (Exception e) {
            call.reject("Failed to set employee identity: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void startActiveSession(PluginCall call) {
        try {
            Context context = getContext();
            String employeeId = call.getString("employeeId");
            String employeeName = call.getString("employeeName", "");
            String townCity = call.getString("townCity", "Raniganj HQ");
            String date = call.getString("date");
            String checkInTime = call.getString("checkInTime");

            if (employeeId != null && date != null && checkInTime != null) {
                OfficeGeofenceHelper.startActiveSession(context, employeeId, employeeName, townCity, date, checkInTime);
                JSObject ret = new JSObject();
                ret.put("success", true);
                call.resolve(ret);
            } else {
                call.reject("Missing required parameters: employeeId, date, checkInTime");
            }
        } catch (Exception e) {
            call.reject("Failed to start active session: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void clearActiveSession(PluginCall call) {
        try {
            Context context = getContext();
            OfficeGeofenceHelper.clearActiveSession(context);
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to clear active session: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void cancelPendingExit(PluginCall call) {
        try {
            Context context = getContext();
            OfficeGeofenceHelper.cancelPendingExit(context);
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to cancel pending exit: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void forceSyncPendingEvents(PluginCall call) {
        try {
            Context context = getContext();
            OfficeGeofenceHelper.triggerBackgroundSync(context);
            JSObject ret = new JSObject();
            ret.put("success", true);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to force sync pending events: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void getActiveAttendanceState(PluginCall call) {
        try {
            Context context = getContext();
            JSONObject session = OfficeGeofenceHelper.getActiveSession(context);
            android.content.SharedPreferences prefs = context.getSharedPreferences(OfficeGeofenceHelper.PREFS_NAME, Context.MODE_PRIVATE);
            JSObject ret = new JSObject();

            String recExit = session != null ? session.optString("recordedExitTime", null) : null;
            if (recExit == null || "null".equalsIgnoreCase(recExit) || recExit.trim().isEmpty()) {
                recExit = prefs.getString(OfficeGeofenceHelper.KEY_LAST_EXIT_TIME, null);
            }
            boolean hasValidExitTime = recExit != null && !"null".equalsIgnoreCase(recExit) && !recExit.trim().isEmpty();

            boolean pendingConf = hasValidExitTime && ((session != null && session.optBoolean("pendingCheckoutConfirmation", false)) ||
                    prefs.getBoolean("pendingCheckoutConfirmation", false) ||
                    "PENDING_EXIT_CONFIRMATION".equalsIgnoreCase(session != null ? session.optString("sessionState", "") : prefs.getString("sessionState", "")) ||
                    "PENDING_AUTO_CHECKOUT".equalsIgnoreCase(session != null ? session.optString("currentState", "") : prefs.getString("currentState", "")));

            if (session != null || pendingConf || (recExit != null && !recExit.trim().isEmpty())) {
                ret.put("hasActiveSession", true);
                ret.put("attendanceId", session != null ? session.optString("attendanceId") : prefs.getString("attendanceId", ""));
                ret.put("employeeId", session != null ? session.optString("employeeId", prefs.getString("employee_id", "")) : prefs.getString("employee_id", ""));
                ret.put("employeeName", session != null ? session.optString("employeeName", prefs.getString("employee_name", "")) : prefs.getString("employee_name", ""));
                ret.put("townCity", session != null ? session.optString("townCity", prefs.getString("town_city", "Raniganj HQ")) : prefs.getString("town_city", "Raniganj HQ"));

                java.text.SimpleDateFormat sdfDate = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US);
                sdfDate.setTimeZone(java.util.TimeZone.getTimeZone("Asia/Kolkata"));
                String todayDate = sdfDate.format(new java.util.Date());

                ret.put("date", session != null ? session.optString("date", todayDate) : todayDate);
                ret.put("checkInTime", session != null ? session.optString("checkInTime", "09:00 AM") : "09:00 AM");
                ret.put("attendanceMode", session != null ? session.optString("attendanceMode", "OFFICE") : "OFFICE");
                ret.put("sessionState", session != null ? session.optString("sessionState", pendingConf ? "PENDING_EXIT_CONFIRMATION" : "ACTIVE") : (pendingConf ? "PENDING_EXIT_CONFIRMATION" : "ACTIVE"));
                ret.put("checkoutStatus", session != null ? session.optString("checkoutStatus", pendingConf ? "PENDING_AUTO_CHECKOUT" : "ACTIVE") : (pendingConf ? "PENDING_AUTO_CHECKOUT" : "ACTIVE"));

                if (recExit != null && !"null".equalsIgnoreCase(recExit) && !recExit.trim().isEmpty()) {
                    ret.put("recordedExitTime", recExit);
                } else {
                    ret.put("recordedExitTime", null);
                }

                String exitDetAt = session != null ? session.optString("exitDetectedAt", null) : null;
                if (exitDetAt != null && !"null".equalsIgnoreCase(exitDetAt)) {
                    ret.put("exitDetectedAt", exitDetAt);
                } else {
                    ret.put("exitDetectedAt", null);
                }

                ret.put("exitSource", session != null ? session.optString("exitSource", "NATIVE_GEOFENCE") : "NATIVE_GEOFENCE");
                ret.put("pendingCheckoutConfirmation", pendingConf);

                String pendingEvtId = session != null ? session.optString("pendingCheckoutEventId", prefs.getString("pendingCheckoutEventId", null)) : prefs.getString("pendingCheckoutEventId", null);
                ret.put("pendingCheckoutEventId", pendingEvtId);

                String currState = session != null ? session.optString("currentState", prefs.getString("currentState", pendingConf ? "PENDING_AUTO_CHECKOUT" : "ACTIVE")) : prefs.getString("currentState", pendingConf ? "PENDING_AUTO_CHECKOUT" : "ACTIVE");
                ret.put("currentState", currState);
            } else {
                ret.put("hasActiveSession", false);
            }
            ret.put("isGeofenceRegistered", OfficeGeofenceHelper.isGeofenceRegistered(context));
            ret.put("isLocationServiceRunning", OfficeLocationService.isRunning());
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to get active attendance state: " + e.getMessage(), e);
        }
    }

    @PluginMethod
    public void getDiagnosticInfo(PluginCall call) {
        try {
            Context context = getContext();
            JSONObject diag = OfficeGeofenceHelper.getDiagnosticState(context);
            JSObject ret = JSObject.fromJSONObject(diag);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Failed to get diagnostic info: " + e.getMessage(), e);
        }
    }
}
