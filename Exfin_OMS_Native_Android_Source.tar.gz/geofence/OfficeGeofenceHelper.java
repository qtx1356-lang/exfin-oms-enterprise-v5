package com.exfin.oms.geofence;

import android.Manifest;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.os.Build;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;

import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import com.google.android.gms.tasks.CancellationTokenSource;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Production-Hardened Authoritative Native Background Attendance Engine for EXFIN OMS.
 *
 * MISSION-CRITICAL RELIABILITY ARCHITECTURE:
 * 1. Strict Authoritative 25.0m Boundary: Haversine distance <= 25.0m = INSIDE, > 25.0m = OUTSIDE.
 * 2. 100-meter Secondary Assist / Wake Geofence: Primes native location layer and Fused Location.
 *    Entering/leaving 100m NEVER directly modifies attendance state.
 * 3. Accuracy & Jitter Filtering: Rejects accuracy > 50.0m. Requires consecutive confirmations or hysteresis.
 * 4. Debounced Boundary Transitions: Prevents rapid ping-pong transitions (60s minimum transition interval).
 * 5. Idempotent Deduplication: Deterministic canonical event IDs prevent duplicate check-ins or check-outs.
 * 6. Autonomous Background HTTP Queue: Direct sync to /api/median-background-location with automatic network recovery.
 * 7. Multi-OS Android 12/13/14/15/16 Compliance: Proper PendingIntent flags, ForegroundServiceTypes, and power locks.
 */
public class OfficeGeofenceHelper {
    public static final String TAG = "OfficeGeofenceHelper";

    // Office Geofence Authoritative Parameters
    public static final String OFFICE_NAME = "EXFIN OFFICE";
    public static final double OFFICE_LAT = 23.616227;
    public static final double OFFICE_LNG = 87.117063;

    // 25-meter Authoritative Attendance Boundary (STRICTLY UNCHANGED)
    public static final float AUTHORITATIVE_RADIUS_METERS = 25.0f; // 25m Authoritative Boundary (UNCHANGED)

    // 300-meter Secondary Assist / Wake Boundary ONLY:
    // "WAKE/ASSIST ONLY — NEVER AUTHORITATIVE FOR ATTENDANCE"
    // Responsible ONLY for waking/activating native location monitoring, obtaining fresh/high-quality location,
    // and verifying actual distance. Entering or exiting 300m MUST NEVER directly modify attendance state.
    public static final float ASSIST_RADIUS_METERS = 300.0f; // 300m Assist Radius ONLY
    public static final float WAKEUP_TRIGGER_RADIUS_METERS = ASSIST_RADIUS_METERS; // 300m Assist

    public static final float MAX_USABLE_ACCURACY_METERS = 50.0f; // Reject fixes with accuracy > 50m
    public static final long MAX_ATTENDANCE_LOCATION_AGE_MS = 120000L; // 2 minutes max age for authoritative attendance mutation
    public static final long MAX_AUTHORITATIVE_CHECKIN_LOCATION_AGE_MS = 15000L; // 15 seconds max age for authoritative check-in location fix
    public static final long MIN_TRANSITION_COOLDOWN_MS = 60000L; // 60s cooldown to prevent boundary oscillation
    public static final String DEFAULT_SERVER_URL = "https://exfin-oms-enterprise-v5.pages.dev";

    public static final String GEOFENCE_ID_PRIMARY_25M = "exfin_office_geofence_auth_25m";
    public static final String GEOFENCE_ID_ASSIST_300M = "exfin_office_geofence_assist_300m";
    public static final String GEOFENCE_ID_ASSIST_100M = GEOFENCE_ID_ASSIST_300M; // Backward-compatible alias
    public static final String GEOFENCE_ID = GEOFENCE_ID_PRIMARY_25M;
    public static final int SCHEMA_VERSION = 4;

    public static final String KEY_ENGINE_READY = "engine_ready";
    public static final String KEY_LAST_REGISTRATION_ATTEMPT = "last_registration_attempt";
    public static final String KEY_REGISTRATION_ERROR = "last_registration_error";

    // Persistent SharedPreferences Storage
    public static final String PREFS_NAME = "exfin_native_geofence_prefs";
    public static final String KEY_EVENTS = "unconsumed_geofence_events";
    public static final String KEY_SYNC_QUEUE = "exfin_native_sync_queue";
    public static final String KEY_ACTIVE_SESSION = "active_attendance_session";
    public static final String KEY_LAST_LOCATION_DIAGNOSTIC = "last_location_diagnostic";
    public static final String KEY_IS_REGISTERED = "is_geofence_registered";
    public static final String KEY_LAST_KNOWN_STATE = "last_known_inside_outside_state"; // "INSIDE", "OUTSIDE", "UNKNOWN"
    public static final String KEY_LAST_CHECKIN_TIMESTAMP = "last_check_in_timestamp";
    public static final String KEY_LAST_CHECKOUT_TIMESTAMP = "last_check_out_timestamp";
    public static final String KEY_LAST_TRANSITION_TIMESTAMP = "last_transition_timestamp";
    public static final String KEY_LAST_PROCESSED_EVENT_ID = "last_processed_geofence_event_id";
    public static final String KEY_LAST_NATIVE_TRIGGER = "last_native_trigger_time";
    public static final String KEY_LAST_NATIVE_ERROR = "last_native_error";
    public static final String KEY_LAST_SYNC_TIME = "last_sync_timestamp";
    public static final String KEY_LAST_EXIT_TIME = "last_native_exit_time";
    public static final String KEY_LAST_EXIT_DATE = "last_native_exit_date";
    public static final String KEY_LAST_EXIT_EMPLOYEE_ID = "last_native_exit_employee_id";
    public static final String KEY_LAST_EXIT_SESSION_ID = "last_native_exit_session_id";
    public static final String KEY_LAST_RETURN_TIME = "last_native_return_time";
    public static final String STATE_EXIT_PROMPT_RESOLVED_OUTSIDE = "EXIT_PROMPT_RESOLVED_OUTSIDE";
    public static final String KEY_EXIT_PROMPT_RESOLVED_OUTSIDE = "exit_prompt_resolved_outside";

    public static boolean isExitPromptResolvedOutside(Context context) {
        if (context == null) return false;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            boolean isResolved = prefs.getBoolean(KEY_EXIT_PROMPT_RESOLVED_OUTSIDE, false);
            JSONObject session = getActiveSession(context);
            if (session != null) {
                String state = session.optString("sessionState", "");
                if (STATE_EXIT_PROMPT_RESOLVED_OUTSIDE.equalsIgnoreCase(state) || "RETURNING_TO_OFFICE".equalsIgnoreCase(state) || session.optBoolean("exitPromptResolvedOutside", false)) {
                    return true;
                }
            }
            return isResolved;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getAttendanceState(Context context) {
        if (context == null) return "UNKNOWN";
        try {
            JSONObject session = getActiveSession(context);
            if (session != null) {
                return session.optString("sessionState", "UNKNOWN");
            }
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            return prefs.getString(KEY_LAST_KNOWN_STATE, "UNKNOWN");
        } catch (Exception e) {
            return "UNKNOWN";
        }
    }

    private static PendingIntent geofencePendingIntent;
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final ScheduledExecutorService scheduledExecutor = Executors.newSingleThreadScheduledExecutor();
    private static ScheduledFuture<?> activeAssistTask = null;
    private static ScheduledFuture<?> assistTimeoutTask = null;
    private static LocationCallback assistLocationCallback = null;
    private static final AtomicBoolean isAssistMonitoringActive = new AtomicBoolean(false);
    private static final AtomicInteger assistChecksCount = new AtomicInteger(0);
    private static boolean isSyncRunning = false;
    private static boolean isNetworkCallbackRegistered = false;
    private static final AtomicBoolean isRetryScheduled = new AtomicBoolean(false);

    // Consecutive reading trackers for GPS noise / jitter suppression
    private static int consecutiveOutsideReadings = 0;
    private static int consecutiveInsideReadings = 0;

    /**
     * Registers the authoritative 25m geofence and secondary 300m assist geofence.
     */
    public static void registerOfficeGeofence(Context context) {
        if (context == null) return;

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "[NATIVE ATTENDANCE] Cannot register geofence: Precise location is disabled (only approximate location granted).");
            } else {
                Log.w(TAG, "[NATIVE ATTENDANCE] Cannot register geofence: Location permissions not granted.");
            }
            setGeofenceRegistered(context, false);
            return;
        }

        // Avoid redundant duplicate re-registration if already active with exact current configuration
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        boolean isRegistered = prefs.getBoolean(KEY_IS_REGISTERED, false);
        int regVersion = prefs.getInt("geofence_registered_version", 0);
        float regAssist = prefs.getFloat("geofence_registered_assist_radius", 0f);
        if (isRegistered && regVersion == SCHEMA_VERSION && Math.abs(regAssist - ASSIST_RADIUS_METERS) < 0.1f) {
            Log.d(TAG, "[NATIVE ATTENDANCE] Geofences already active (25m auth + 300m assist). Skipping duplicate registration.");
            return;
        }

        try {
            GeofencingClient geofencingClient = LocationServices.getGeofencingClient(context);

            // 1. Primary Authoritative 25m Geofence:
            // Responsible for immediate 25m boundary detection.
            Geofence authGeofence25m = new Geofence.Builder()
                    .setRequestId(GEOFENCE_ID_PRIMARY_25M)
                    .setCircularRegion(OFFICE_LAT, OFFICE_LNG, AUTHORITATIVE_RADIUS_METERS)
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT | Geofence.GEOFENCE_TRANSITION_DWELL)
                    .setLoiteringDelay(3000) // 3 second dwell
                    .setNotificationResponsiveness(0) // Immediate wake-up
                    .build();

            // 2. Secondary 300m Assist Geofence:
            // "WAKE/ASSIST ONLY — NEVER AUTHORITATIVE FOR ATTENDANCE"
            // Responsible ONLY for waking/activating native location monitoring, obtaining fresh/high-quality location,
            // and verifying actual distance. Entering/leaving 300m MUST NOT directly modify attendance state.
            Geofence assistGeofence300m = new Geofence.Builder()
                    .setRequestId(GEOFENCE_ID_ASSIST_300M)
                    .setCircularRegion(OFFICE_LAT, OFFICE_LNG, ASSIST_RADIUS_METERS)
                    .setExpirationDuration(Geofence.NEVER_EXPIRE)
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_EXIT | Geofence.GEOFENCE_TRANSITION_DWELL)
                    .setLoiteringDelay(5000) // 5 second dwell
                    .setNotificationResponsiveness(5000) // 5s responsiveness, battery-conscious
                    .build();

            GeofencingRequest request = new GeofencingRequest.Builder()
                    .setInitialTrigger(0) // Raw geofence events only wake/prime; 0 prevents initial trigger false positives upon registration
                    .addGeofence(authGeofence25m)
                    .addGeofence(assistGeofence300m)
                    .build();

            PendingIntent pendingIntent = getGeofencePendingIntent(context);

            geofencingClient.addGeofences(request, pendingIntent)
                    .addOnSuccessListener(aVoid -> {
                        String empId = prefs.getString("employee_id", "UNKNOWN");
                        Log.i(TAG, "[NATIVE_GEOFENCE_REGISTERED] employeeId=" + empId + " 300mAssistRadius=" + ASSIST_RADIUS_METERS + "m 25mAuthRadius=" + AUTHORITATIVE_RADIUS_METERS + "m");
                        SharedPreferences.Editor editor = prefs.edit();
                        editor.putBoolean(KEY_IS_REGISTERED, true);
                        editor.putInt("geofence_registered_version", SCHEMA_VERSION);
                        editor.putFloat("geofence_registered_assist_radius", ASSIST_RADIUS_METERS);
                        editor.apply();
                    })
                    .addOnFailureListener(e -> {
                        Log.e(TAG, "Failed to register office geofence: " + e.getMessage(), e);
                        setGeofenceRegistered(context, false);
                        recordNativeError(context, "Registration failed: " + e.getMessage());
                    });
        } catch (SecurityException se) {
            Log.e(TAG, "SecurityException registering geofence: " + se.getMessage(), se);
            recordNativeError(context, "SecurityException: " + se.getMessage());
        } catch (Exception e) {
            Log.e(TAG, "Exception registering geofence: " + e.getMessage(), e);
            recordNativeError(context, "Exception: " + e.getMessage());
        }
    }

    public static void removeOfficeGeofence(Context context) {
        if (context == null) return;
        try {
            GeofencingClient geofencingClient = LocationServices.getGeofencingClient(context);
            PendingIntent pendingIntent = getGeofencePendingIntent(context);
            geofencingClient.removeGeofences(pendingIntent)
                    .addOnCompleteListener(task -> {
                        Log.i(TAG, "Office geofence removed.");
                        setGeofenceRegistered(context, false);
                    });
        } catch (Exception e) {
            Log.e(TAG, "Error removing geofence: " + e.getMessage(), e);
        }
    }

    private static PendingIntent getGeofencePendingIntent(Context context) {
        if (geofencePendingIntent != null) {
            return geofencePendingIntent;
        }
        Intent intent = new Intent(context, GeofenceBroadcastReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            flags |= PendingIntent.FLAG_MUTABLE;
        }
        geofencePendingIntent = PendingIntent.getBroadcast(context, 2501, intent, flags);
        return geofencePendingIntent;
    }

    /**
     * Exact Haversine distance calculation in meters.
     */
    public static double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371000; // Earth radius in meters
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                   Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                   Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    private static void safeFinishPendingResult(BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        if (pendingResult != null && finishedFlag != null) {
            if (finishedFlag.compareAndSet(false, true)) {
                try {
                    Log.i(TAG, "[NativeGeofenceLifecycle] GO_ASYNC_FINISHED");
                    pendingResult.finish();
                } catch (Exception e) {
                    Log.w(TAG, "Error finishing BroadcastReceiver.PendingResult", e);
                }
            }
        }
    }

    /**
     * Handles geofence wake-up trigger and begins Stage 2 high-accuracy location verification.
     */
    public static void handleNativeGeofenceTransition(Context context, int transitionType, Location triggerLocation, BroadcastReceiver.PendingResult pendingResult) {
        handleNativeGeofenceTransition(context, transitionType, triggerLocation, null, pendingResult);
    }

    public static void handleNativeGeofenceTransition(Context context, int transitionType, Location triggerLocation, List<String> triggeringGeofenceIds, BroadcastReceiver.PendingResult pendingResult) {
        final AtomicBoolean finishedFlag = new AtomicBoolean(false);
        if (context == null) {
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        saveLastNativeTrigger(context, System.currentTimeMillis());

        // Acquire partial WakeLock to keep CPU active during high-accuracy fix & sync
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = null;
        if (pm != null) {
            try {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "exfin:geofence_verification");
                wakeLock.acquire(15000); // 15s max wake lock
            } catch (Exception e) {
                Log.w(TAG, "Could not acquire WakeLock: " + e.getMessage());
            }
        }

        final PowerManager.WakeLock finalWakeLock = wakeLock;

        boolean isOnlyAssistGeofence = (triggeringGeofenceIds != null &&
                                        (triggeringGeofenceIds.contains(GEOFENCE_ID_ASSIST_300M) || triggeringGeofenceIds.contains("exfin_office_geofence_assist_100m")) &&
                                        !triggeringGeofenceIds.contains(GEOFENCE_ID_PRIMARY_25M));

        executor.execute(() -> {
            try {
                if (isOnlyAssistGeofence) {
                    handleAssist300mTransition(context, transitionType, triggerLocation, pendingResult, finishedFlag);
                } else {
                    requestHighAccuracyLocationAndDecide(context, transitionType, triggerLocation, pendingResult, finishedFlag);
                }
            } catch (Exception e) {
                Log.e(TAG, "Error in handleNativeGeofenceTransition task: " + e.getMessage(), e);
                recordNativeError(context, "handleNativeGeofenceTransition: " + e.getMessage());
                safeFinishPendingResult(pendingResult, finishedFlag);
            } finally {
                if (finalWakeLock != null && finalWakeLock.isHeld()) {
                    try {
                        finalWakeLock.release();
                    } catch (Exception e) {
                        Log.w(TAG, "Error releasing WakeLock: " + e.getMessage());
                    }
                }
            }
        });
    }

    /**
     * Secondary 300m Assist / Wake Handler.
     * "WAKE/ASSIST ONLY — NEVER AUTHORITATIVE FOR ATTENDANCE"
     *
     * STRICT ARCHITECTURAL CONSTRAINTS:
     * 1. 300m is ONLY an assist/wake mechanism to prime high-accuracy Fused Location.
     * 2. Entering 300m MUST NOT directly check in, open attendance, or modify attendance state (if distance > 25m).
     * 3. Leaving 300m MUST NOT checkout or create an attendance EXIT directly.
     * 4. Only authoritative 25m boundary evaluation can modify attendance state.
     * 5. Solves the 270m problem: initial inaccurate/poor fixes (e.g. 270m, 143m acc) are not accepted as proof
     *    of employee being outside. High-accuracy GPS monitoring continues until trustworthy fix <= 25m is obtained.
     * 6. Battery-conscious: temporary approach/attendance confirmation mode runs at ~6s intervals and automatically
     *    stops on check-in, exit/return, departure (>350m), or 150s timeout.
     */
    private static void handleAssist300mTransition(Context context, int transitionType, Location triggerLocation, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        if (context == null) {
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        double trigDist = -1;
        if (triggerLocation != null && !Double.isNaN(triggerLocation.getLatitude()) && !Double.isNaN(triggerLocation.getLongitude())) {
            trigDist = calculateDistance(triggerLocation.getLatitude(), triggerLocation.getLongitude(), OFFICE_LAT, OFFICE_LNG);
        }

        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Exit candidate received");
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Distance from office: " + (trigDist >= 0 ? String.format(Locale.US, "%.1f", trigDist) : "300.0") + "m");
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Current attendance state: " + getAttendanceState(context));
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Exit prompt resolved outside: " + isExitPromptResolvedOutside(context));
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: IGNORE_ASSIST_ONLY");

        Log.i(TAG, "[NATIVE ATTENDANCE] ASSIST GEOFENCE EVENT");
        if (isExitPromptResolvedOutside(context)) {
            Log.i(TAG, "[NATIVE ATTENDANCE] OUTSIDE STATE PRESERVED");
        }

        if (transitionType == Geofence.GEOFENCE_TRANSITION_ENTER || transitionType == Geofence.GEOFENCE_TRANSITION_DWELL) {
            String distEstimateStr = trigDist >= 0 ? Math.round(trigDist) + "m" : "~300m";
            Log.i(TAG, "[NATIVE ATTENDANCE] Assist geofence triggered (300m): distance estimate=" + distEstimateStr);

            // Permission check: Fine location required for 25m authoritative attendance
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    Log.w(TAG, "[NATIVE ATTENDANCE] Precise location unavailable (only coarse/approximate granted). Authoritative 25m attendance decisions require ACCESS_FINE_LOCATION.");
                } else {
                    Log.w(TAG, "[NATIVE ATTENDANCE] Location permission not granted. Assist standing down.");
                }
                safeFinishPendingResult(pendingResult, finishedFlag);
                return;
            }

            // Start temporary high-accuracy monitoring
            startTemporaryAssistMonitoring(context);
            safeFinishPendingResult(pendingResult, finishedFlag);

        } else if (transitionType == Geofence.GEOFENCE_TRANSITION_EXIT) {
            double exitDist = -1;
            if (triggerLocation != null && !Double.isNaN(triggerLocation.getLatitude()) && !Double.isNaN(triggerLocation.getLongitude())) {
                exitDist = calculateDistance(triggerLocation.getLatitude(), triggerLocation.getLongitude(), OFFICE_LAT, OFFICE_LNG);
            }
            Log.i(TAG, "[NATIVE ATTENDANCE] Assist geofence exited (300m)" + (exitDist >= 0 ? ": distance=" + Math.round(exitDist) + "m" : "") + ". Stopping temporary high accuracy monitoring. Attendance state strictly UNCHANGED.");
            stopTemporaryAssistMonitoring(context, "exit");
            safeFinishPendingResult(pendingResult, finishedFlag);
        } else {
            safeFinishPendingResult(pendingResult, finishedFlag);
        }
    }

    private static void handleAssist100mTransition(Context context, int transitionType, Location triggerLocation, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        handleAssist300mTransition(context, transitionType, triggerLocation, pendingResult, finishedFlag);
    }

    /**
     * Starts temporary high-accuracy location monitoring upon 300m assist zone entry.
     * Reuses FusedLocationProviderClient with Priority.PRIORITY_HIGH_ACCURACY.
     * Interval: 6s (fastest 3s, max delay 10s).
     */
    public static synchronized void startTemporaryAssistMonitoring(Context context) {
        if (context == null) return;
        final Context appContext = context.getApplicationContext();

        // If user already has an active session in ACTIVE state for today, assist entry monitoring is not needed
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdfDate.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String todayDate = sdfDate.format(new Date());

        JSONObject activeSession = getActiveSession(appContext);
        if (activeSession != null) {
            String sessDate = activeSession.optString("date", "");
            String state = activeSession.optString("sessionState", "");
            if (todayDate.equals(sessDate) && "ACTIVE".equalsIgnoreCase(state)) {
                Log.d(TAG, "[NATIVE ATTENDANCE] Active session already present in ACTIVE state for today (" + todayDate + "). Entry assist monitoring not required.");
                return;
            }
        }

        // Permission check
        if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if (ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                Log.w(TAG, "[NATIVE ATTENDANCE] Precise location unavailable (only coarse/approximate granted). Cannot start high-accuracy 25m monitoring.");
            } else {
                Log.w(TAG, "[NATIVE ATTENDANCE] Location permission not granted. High-accuracy monitoring aborted.");
            }
            return;
        }

        // If already actively monitoring, do not duplicate callbacks; reset timeout watchdog
        if (isAssistMonitoringActive.get()) {
            Log.d(TAG, "[NATIVE ATTENDANCE] High accuracy monitoring already active. Resetting watchdog timer.");
            resetAssistTimeoutWatchdog(appContext);
            return;
        }

        isAssistMonitoringActive.set(true);
        assistChecksCount.set(0);
        Log.i(TAG, "[NATIVE ATTENDANCE] Temporary high-accuracy location started (Interval: 6s, Priority: PRIORITY_HIGH_ACCURACY)");

        try {
            FusedLocationProviderClient fusedClient = LocationServices.getFusedLocationProviderClient(appContext);

            LocationRequest assistRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 6000)
                    .setMinUpdateIntervalMillis(3000)
                    .setMaxUpdateDelayMillis(10000)
                    .setWaitForAccurateLocation(true)
                    .build();

            assistLocationCallback = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {
                    if (locationResult == null || !isAssistMonitoringActive.get()) return;
                    for (Location loc : locationResult.getLocations()) {
                        if (loc != null) {
                            processAssistLocationUpdate(appContext, loc);
                        }
                    }
                }
            };

            fusedClient.requestLocationUpdates(assistRequest, assistLocationCallback, Looper.getMainLooper());

            // Immediate fresh fix to prime hardware without waiting for first interval
            CancellationTokenSource cts = new CancellationTokenSource();
            fusedClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.getToken())
                    .addOnSuccessListener(loc -> {
                        if (loc != null && isAssistMonitoringActive.get()) {
                            processAssistLocationUpdate(appContext, loc);
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.d(TAG, "[NATIVE ATTENDANCE] Initial getCurrentLocation warm-up: " + e.getMessage());
                    });

            // Start 150-second (2.5 minute) timeout watchdog to guarantee battery safety
            resetAssistTimeoutWatchdog(appContext);

        } catch (SecurityException se) {
            Log.e(TAG, "[NATIVE ATTENDANCE] SecurityException starting high-accuracy monitoring: " + se.getMessage());
            isAssistMonitoringActive.set(false);
        } catch (Exception e) {
            Log.e(TAG, "[NATIVE ATTENDANCE] Exception starting high-accuracy monitoring: " + e.getMessage(), e);
            isAssistMonitoringActive.set(false);
        }
    }

    private static synchronized void resetAssistTimeoutWatchdog(Context context) {
        if (assistTimeoutTask != null) {
            try {
                assistTimeoutTask.cancel(false);
            } catch (Exception ignored) {}
            assistTimeoutTask = null;
        }
        assistTimeoutTask = scheduledExecutor.schedule(() -> {
            stopTemporaryAssistMonitoring(context, "timeout");
        }, 150, TimeUnit.SECONDS);
    }

    /**
     * Processes high-accuracy location updates during temporary assist monitoring.
     * Evaluates accuracy, freshness, and the strict 25m authoritative attendance boundary.
     * Resolves the 270m problem: initial inaccurate/coarse fixes are rejected and monitoring continues.
     */
    private static void processAssistLocationUpdate(Context context, Location location) {
        if (context == null || location == null || !isAssistMonitoringActive.get()) return;

        double lat = location.getLatitude();
        double lng = location.getLongitude();
        float accuracy = location.hasAccuracy() ? location.getAccuracy() : 999.0f;
        long now = System.currentTimeMillis();
        long ageMs = location.getTime() > 0 ? (now - location.getTime()) : 0;
        long ageSec = ageMs / 1000L;
        double distance = calculateDistance(lat, lng, OFFICE_LAT, OFFICE_LNG);

        // Required diagnostic log:
        Log.i(TAG, "[NATIVE ATTENDANCE] Location accuracy=" + Math.round(accuracy) + "m, age=" + ageSec + "s, distance from office=" + Math.round(distance) + "m");
        saveLastLocationDiagnostic(context, lat, lng, accuracy, location.getTime(), distance);

        // 1. Accuracy validation: Reject inaccurate positions (e.g. 270m cell jumps, accuracy > 50m)
        if (!location.hasAccuracy() || accuracy > MAX_USABLE_ACCURACY_METERS) {
            Log.w(TAG, "[NATIVE ATTENDANCE] Location rejected: accuracy=" + Math.round(accuracy) + "m (exceeds " + Math.round(MAX_USABLE_ACCURACY_METERS) + "m limit). Inaccurate location (e.g. 270m jump) - continuing high-accuracy acquisition.");
            return;
        }

        // 2. Freshness validation: Reject stale cached fixes (must be <= 15s old for check-in)
        if (ageMs > MAX_AUTHORITATIVE_CHECKIN_LOCATION_AGE_MS || ageMs < -1000L) {
            Log.w(TAG, "[NATIVE ATTENDANCE] Location rejected: stale location age=" + ageSec + "s (must be <= " + (MAX_AUTHORITATIVE_CHECKIN_LOCATION_AGE_MS / 1000) + "s)");
            return;
        }

        // 3. Precise location validation
        if (!isLocationTrustworthyForCheckIn(location)) {
            Log.w(TAG, "[NATIVE ATTENDANCE] Location rejected: failed check-in trustworthiness validation");
            return;
        }

        // Location is trustworthy and fresh!
        Log.i(TAG, "[NATIVE ATTENDANCE] Location accepted for authoritative evaluation");

        // 4. Authoritative boundary decision: STRICT 25-METER RADIUS
        if (distance <= AUTHORITATIVE_RADIUS_METERS) {
            Log.i(TAG, "[NATIVE ATTENDANCE] Authoritative check-in triggered (<= 25m): distance=" + Math.round(distance) + "m");

            // Stop temporary high-accuracy monitoring to preserve battery
            stopTemporaryAssistMonitoring(context, "check-in");

            // Execute existing authoritative transition
            evaluateAttendanceDecision(context, location, "FUSED_ASSIST_HIGH_ACCURACY", Geofence.GEOFENCE_TRANSITION_ENTER, null, null);
            return;
        } else {
            // Distance is > 25m (e.g. 270m, 150m, 80m, 50m, 30m)
            Log.i(TAG, "[NATIVE ATTENDANCE] Authoritative check-in boundary not met: distance=" + Math.round(distance) + "m > " + Math.round(AUTHORITATIVE_RADIUS_METERS) + "m. Attendance state UNCHANGED. Monitoring continues.");

            // If the employee is clearly far away (> 350m), stop monitoring to save battery
            if (distance > 350.0) {
                stopTemporaryAssistMonitoring(context, "away");
            }
        }
    }

    public static synchronized void stopTemporaryAssistMonitoring(Context context) {
        stopTemporaryAssistMonitoring(context, "unspecified");
    }

    public static synchronized void stopTemporaryAssistMonitoring(Context context, String reason) {
        if (!isAssistMonitoringActive.getAndSet(false)) {
            return;
        }
        try {
            if (assistTimeoutTask != null) {
                assistTimeoutTask.cancel(false);
                assistTimeoutTask = null;
            }
            if (activeAssistTask != null) {
                activeAssistTask.cancel(true);
                activeAssistTask = null;
            }
            if (assistLocationCallback != null && context != null) {
                FusedLocationProviderClient fused = LocationServices.getFusedLocationProviderClient(context.getApplicationContext());
                fused.removeLocationUpdates(assistLocationCallback);
                assistLocationCallback = null;
            }
            Log.i(TAG, "[NATIVE ATTENDANCE] Temporary monitoring stopped (reason: " + reason + ")");
        } catch (Exception e) {
            Log.w(TAG, "Error stopping assist monitoring: " + e.getMessage());
        }
    }

    public static synchronized void stopTemporaryAssistAwareness() {
        stopTemporaryAssistMonitoring(null);
    }

    public static synchronized void startTemporaryAssistAwarenessWindow(Context context) {
        startTemporaryAssistMonitoring(context);
    }

    private static void requestHighAccuracyLocationAndDecide(Context context, int transitionType, Location triggerLocation, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.w(TAG, "ACCESS_FINE_LOCATION not granted during geofence wake-up");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        FusedLocationProviderClient fusedClient = LocationServices.getFusedLocationProviderClient(context);

        // Immediate diagnostic inspection of cached location (awareness only; NEVER mutates attendance per Rule 1)
        try {
            fusedClient.getLastLocation().addOnSuccessListener(lastLoc -> {
                if (lastLoc != null) {
                    double lastDist = calculateDistance(lastLoc.getLatitude(), lastLoc.getLongitude(), OFFICE_LAT, OFFICE_LNG);
                    long ageMs = lastLoc.getTime() > 0 ? (System.currentTimeMillis() - lastLoc.getTime()) : -1;
                    Log.i(TAG, "[NATIVE_ATTENDANCE_TIMESTAMP] Cached location inspected: age=" + ageMs + "ms, dist=" + String.format(Locale.US, "%.1f", lastDist) + "m, provider=CACHED_LOCATION (Strictly ignored for attendance mutation per Rule 1)");
                    saveLastLocationDiagnostic(context, lastLoc.getLatitude(), lastLoc.getLongitude(), lastLoc.getAccuracy(), lastLoc.getTime(), lastDist);
                }
            });
        } catch (Exception ignored) {}

        // PRIORITY 1: Always request fresh high-accuracy location first
        requestFreshLocation(context, fusedClient, transitionType, triggerLocation, pendingResult, finishedFlag);
    }

    private static void requestFreshLocation(Context context, FusedLocationProviderClient fusedClient, int transitionType, Location triggerLocation, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        final CancellationTokenSource cts = new CancellationTokenSource();
        final AtomicBoolean handled = new AtomicBoolean(false);

        // Strict 5-second watchdog timer: Play Services getCurrentLocation must not block receiver completion
        final ScheduledFuture<?> watchdogTask = scheduledExecutor.schedule(() -> {
            if (handled.compareAndSet(false, true)) {
                try {
                    cts.cancel();
                } catch (Exception ignored) {}
                Log.i(TAG, "[Watchdog] Fresh location request exceeded 5s. Falling back to trustworthy geofence trigger if available.");
                fallbackToTrustworthyLocation(context, fusedClient, triggerLocation, transitionType, pendingResult, finishedFlag);
            }
        }, 5000, TimeUnit.MILLISECONDS);

        try {
            fusedClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, cts.getToken())
                    .addOnSuccessListener(location -> {
                        if (handled.compareAndSet(false, true)) {
                            try { watchdogTask.cancel(false); } catch (Exception ignored) {}
                            if (location != null && isLocationTrustworthyForAttendance(location)) {
                                double dist = calculateDistance(location.getLatitude(), location.getLongitude(), OFFICE_LAT, OFFICE_LNG);
                                boolean isEnterOrDwell = (transitionType == Geofence.GEOFENCE_TRANSITION_ENTER || transitionType == Geofence.GEOFENCE_TRANSITION_DWELL);
                                boolean isExit = (transitionType == Geofence.GEOFENCE_TRANSITION_EXIT);

                                Log.i(TAG, "[FUSED_CURRENT] Fresh high-accuracy location obtained: " + location.getLatitude() + ", " + location.getLongitude() +
                                        " (acc=" + location.getAccuracy() + "m, dist=" + String.format(Locale.US, "%.1f", dist) + "m)");

                                if (isEnterOrDwell) {
                                    if (dist <= AUTHORITATIVE_RADIUS_METERS && isLocationTrustworthyForCheckIn(location)) {
                                        evaluateAttendanceDecision(context, location, "FUSED_CURRENT", transitionType, pendingResult, finishedFlag);
                                        return;
                                    } else {
                                        Log.i(TAG, "[FUSED_CURRENT] Fresh location did not confirm enter (dist=" + String.format(Locale.US, "%.1f", dist) + "m for transition=" + transitionType + "). Activating temporary high-accuracy monitoring to resolve approach.");
                                        startTemporaryAssistMonitoring(context);
                                        fallbackToTrustworthyLocation(context, fusedClient, triggerLocation, transitionType, pendingResult, finishedFlag);
                                    }
                                } else if (isExit) {
                                    if (dist > AUTHORITATIVE_RADIUS_METERS && isLocationTrustworthyForAttendance(location)) {
                                        processExitTransition(context, location, "NATIVE_GEOFENCE_VERIFIED", "FUSED_CURRENT", pendingResult, finishedFlag);
                                        return;
                                    } else {
                                        Log.i(TAG, "[FUSED_CURRENT] Fresh location did not confirm exit (" + String.format(Locale.US, "%.1f", dist) + "m for transition=" + transitionType + "). Checking triggeringLocation fallback.");
                                        fallbackToTrustworthyLocation(context, fusedClient, triggerLocation, transitionType, pendingResult, finishedFlag);
                                    }
                                }
                            } else {
                                Log.w(TAG, "[FUSED_CURRENT] Location is null or not trustworthy. Checking fallback.");
                                fallbackToTrustworthyLocation(context, fusedClient, triggerLocation, transitionType, pendingResult, finishedFlag);
                            }
                        }
                    })
                    .addOnFailureListener(e -> {
                        if (handled.compareAndSet(false, true)) {
                            try { watchdogTask.cancel(false); } catch (Exception ignored) {}
                            Log.w(TAG, "getCurrentLocation failed: " + e.getMessage() + ". Falling back to triggeringLocation.");
                            fallbackToTrustworthyLocation(context, fusedClient, triggerLocation, transitionType, pendingResult, finishedFlag);
                        }
                    });
        } catch (SecurityException se) {
            if (handled.compareAndSet(false, true)) {
                try { watchdogTask.cancel(false); } catch (Exception ignored) {}
                Log.e(TAG, "SecurityException getting current location", se);
                fallbackToTrustworthyLocation(context, fusedClient, triggerLocation, transitionType, pendingResult, finishedFlag);
            }
        } catch (Exception e) {
            if (handled.compareAndSet(false, true)) {
                try { watchdogTask.cancel(false); } catch (Exception ignored) {}
                Log.e(TAG, "Exception getting current location", e);
                fallbackToTrustworthyLocation(context, fusedClient, triggerLocation, transitionType, pendingResult, finishedFlag);
            }
        }
    }

    private static void fallbackToTrustworthyLocation(Context context, FusedLocationProviderClient fusedClient, Location triggerLocation, int transitionType, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        boolean isEnterOrDwell = (transitionType == Geofence.GEOFENCE_TRANSITION_ENTER || transitionType == Geofence.GEOFENCE_TRANSITION_DWELL);
        boolean isExit = (transitionType == Geofence.GEOFENCE_TRANSITION_EXIT);

        // PRIORITY 2: Check if geofence triggerLocation is valid, fresh, and trustworthy
        if (triggerLocation != null) {
            double trigDist = calculateDistance(triggerLocation.getLatitude(), triggerLocation.getLongitude(), OFFICE_LAT, OFFICE_LNG);
            if (isEnterOrDwell && trigDist <= AUTHORITATIVE_RADIUS_METERS && isLocationTrustworthyForCheckIn(triggerLocation)) {
                Log.i(TAG, "[GEOFENCE_TRIGGER] Geofence triggerLocation verified inside 25m boundary: " +
                        String.format(Locale.US, "%.1f", trigDist) + "m <= " + AUTHORITATIVE_RADIUS_METERS +
                        "m (acc=" + triggerLocation.getAccuracy() + "m). Executing check-in.");
                evaluateAttendanceDecision(context, triggerLocation, "GEOFENCE_TRIGGER", transitionType, pendingResult, finishedFlag);
                return;
            } else if (isExit && trigDist > AUTHORITATIVE_RADIUS_METERS && isLocationTrustworthyForAttendance(triggerLocation)) {
                Log.i(TAG, "[GEOFENCE_TRIGGER] Geofence triggerLocation verified outside 25m boundary: " +
                        String.format(Locale.US, "%.1f", trigDist) + "m > " + AUTHORITATIVE_RADIUS_METERS +
                        "m (acc=" + triggerLocation.getAccuracy() + "m). Executing exit processing.");
                processExitTransition(context, triggerLocation, "NATIVE_GEOFENCE_TRIGGER", "GEOFENCE_TRIGGER", pendingResult, finishedFlag);
                return;
            }
        }

        // Rule 1 Enforcement: Inspect cached location purely for diagnostics, NEVER mutate attendance state
        try {
            fusedClient.getLastLocation().addOnSuccessListener(lastLoc -> {
                if (lastLoc != null) {
                    double d = calculateDistance(lastLoc.getLatitude(), lastLoc.getLongitude(), OFFICE_LAT, OFFICE_LNG);
                    long age = lastLoc.getTime() > 0 ? (System.currentTimeMillis() - lastLoc.getTime()) : -1;
                    Log.i(TAG, "[NATIVE_ATTENDANCE_TIMESTAMP] Cached location ignored for attendance decision: age=" + age + "ms, dist=" + String.format(Locale.US, "%.1f", d) + "m, provider=CACHED_LOCATION");
                }
            });
        } catch (Exception ignored) {}

        // Google Play Services hardware geofence verified the authoritative 25m boundary transition.
        // Primary 25m Exit Fallback: Creates an authoritative PENDING CHECKOUT CANDIDATE.
        // Does NOT finalize checkout. Does NOT fabricate synthetic GPS coordinates.
        if (isExit) {
            Log.i(TAG, "[EXIT Hardware Fallback] Play Services hardware verified exit from 25m geofence without fresh GPS fix. Processing geofence exit candidate.");
            processGeofenceExitCandidate(context, triggerLocation, "NATIVE_GEOFENCE_HARDWARE_EXIT", pendingResult, finishedFlag);
        } else {
            // Raw Android geofence events must ONLY wake/prime the native location engine.
            // A geofence enter event MUST NEVER by itself create an authoritative check-in.
            // Synthetic HARDWARE_FALLBACK for check-in is strictly removed.
            Log.i(TAG, "[AUTO_CHECKIN_PENDING_VERIFICATION] Play Services geofence enter event did not obtain a fresh physical location <= 25m. Activating temporary high-accuracy monitoring to acquire fresh location.");
            startTemporaryAssistMonitoring(context);
            safeFinishPendingResult(pendingResult, finishedFlag);
        }
    }

    private static Location getSystemLastKnownLocation(Context context) {
        try {
            LocationManager lm = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
            if (lm == null) return null;
            Location loc = null;
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            }
            if (loc == null && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                loc = lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            }
            return loc;
        } catch (SecurityException se) {
            return null;
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Validates location coordinates, freshness, and accuracy.
     * Rejects accuracy > 50.0m to prevent inaccurate cell tower jumps from falsifying attendance.
     */
    public static boolean validateLocation(Location location) {
        if (location == null) return false;
        double lat = location.getLatitude();
        double lng = location.getLongitude();
        if (Double.isNaN(lat) || Double.isNaN(lng) || Double.isInfinite(lat) || Double.isInfinite(lng)) return false;
        if (lat < -90.0 || lat > 90.0 || lng < -180.0 || lng > 180.0) return false;
        if (Math.abs(lat) < 0.0001 && Math.abs(lng) < 0.0001) return false; // Reject 0,0

        // Reject fixes with poor accuracy (> 50m)
        if (location.hasAccuracy() && location.getAccuracy() > MAX_USABLE_ACCURACY_METERS) {
            Log.d(TAG, "Rejecting location with poor accuracy: " + location.getAccuracy() + "m > " + MAX_USABLE_ACCURACY_METERS + "m");
            return false;
        }

        // Reject stale fixes older than 5 minutes
        long ageMs = System.currentTimeMillis() - location.getTime();
        if (location.getTime() > 0 && ageMs > 300000) {
            Log.d(TAG, "Rejecting stale location fix (age=" + (ageMs / 1000) + "s)");
            return false;
        }
        return true;
    }

    /**
     * Stricter validation for mutating authoritative attendance (CHECK_IN or CHECK_OUT).
     * Must have valid coordinates, accuracy <= 50m, and location.getTime() must be fresh (age <= 2 mins).
     * Stale cached fixes are strictly rejected for attendance mutation.
     */
    public static boolean isLocationTrustworthyForAttendance(Location location) {
        if (!validateLocation(location)) return false;
        if (location.getTime() <= 0) {
            Log.w(TAG, "[ATTENDANCE_FRESHNESS] Rejected location with missing timestamp");
            return false;
        }
        long ageMs = Math.abs(System.currentTimeMillis() - location.getTime());
        if (ageMs > MAX_ATTENDANCE_LOCATION_AGE_MS) {
            Log.w(TAG, "[ATTENDANCE_FRESHNESS] Rejected stale location fix for attendance mutation: age=" + (ageMs / 1000) + "s > " + (MAX_ATTENDANCE_LOCATION_AGE_MS / 1000) + "s (provider=" + location.getProvider() + ")");
            return false;
        }
        return true;
    }

    /**
     * Strictest validation exclusively for Authoritative CHECK_IN:
     * - Coordinates must be valid and non-zero
     * - Accuracy must be <= 50.0m
     * - Fix must have a valid positive timestamp
     * - Wall-clock age must be <= 15000ms (15 seconds)
     * - Elapsed realtime age (when available) must be <= 15000ms
     * - Provider must not be synthetic or hardware fallback
     */
    public static boolean isLocationTrustworthyForCheckIn(Location location) {
        if (!validateLocation(location)) {
            Log.w(TAG, "[CHECKIN_VERIFICATION] Location failed validateLocation");
            return false;
        }
        if (location.getTime() <= 0) {
            Log.w(TAG, "[CHECKIN_VERIFICATION] Rejected location with missing timestamp");
            return false;
        }

        // 1. Android elapsed realtime validation (nanosecond monotonic clock)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            long locElapsedNanos = location.getElapsedRealtimeNanos();
            if (locElapsedNanos > 0) {
                long currentElapsedNanos = SystemClock.elapsedRealtimeNanos();
                long elapsedAgeMs = (currentElapsedNanos - locElapsedNanos) / 1000000L;
                if (elapsedAgeMs > MAX_AUTHORITATIVE_CHECKIN_LOCATION_AGE_MS || elapsedAgeMs < -1000L) {
                    Log.w(TAG, "[CHECKIN_VERIFICATION] Rejected by elapsedRealtime: age=" + elapsedAgeMs + "ms > " + MAX_AUTHORITATIVE_CHECKIN_LOCATION_AGE_MS + "ms");
                    return false;
                }
            }
        }

        // 2. Wall clock freshness validation
        long wallClockAgeMs = Math.abs(System.currentTimeMillis() - location.getTime());
        if (wallClockAgeMs > MAX_AUTHORITATIVE_CHECKIN_LOCATION_AGE_MS) {
            Log.w(TAG, "[CHECKIN_VERIFICATION] Rejected by wallClock: age=" + wallClockAgeMs + "ms > " + MAX_AUTHORITATIVE_CHECKIN_LOCATION_AGE_MS + "ms");
            return false;
        }

        // 3. Provider check: Must not be synthetic or hardware fallback
        String provider = location.getProvider();
        if (provider != null) {
            String lower = provider.toLowerCase(Locale.US);
            if (lower.contains("hardware") || lower.contains("synthetic") || lower.contains("mock")) {
                Log.w(TAG, "[CHECKIN_VERIFICATION] Rejected synthetic provider for check-in: " + provider);
                return false;
            }
        }

        return true;
    }

    /**
     * Diagnostic logging helper required by Rule 13.
     */
    public static void logNativeAttendanceTimestampDiagnostic(String eventType, String source, String locationProvider, Location location, double distance, String employeeId) {
        long locTime = location.getTime();
        long now = System.currentTimeMillis();
        long ageMs = locTime > 0 ? (now - locTime) : 0;

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        String locTimeIso = locTime > 0 ? sdf.format(new Date(locTime)) : "UNKNOWN";
        String createdAtIso = sdf.format(new Date(now));

        JSONObject diag = new JSONObject();
        try {
            diag.put("eventType", eventType);
            diag.put("source", source);
            diag.put("locationProvider", locationProvider);
            diag.put("locationTimestamp", locTimeIso);
            diag.put("locationAgeMs", ageMs);
            diag.put("accuracy", Math.round(location.getAccuracy() * 10.0) / 10.0);
            diag.put("distanceFromOffice", Math.round(distance * 10.0) / 10.0);
            diag.put("createdAt", createdAtIso);
            diag.put("employeeId", employeeId);
        } catch (Exception ignored) {}

        Log.i(TAG, "[NATIVE_ATTENDANCE_TIMESTAMP] " + diag.toString());
    }

    /**
     * Authoritative decision logic:
     * Calculates distance using Haversine formula against EXFIN Office (23.616227, 87.117063).
     * distance <= 25.0m => INSIDE
     * distance > 25.0m => OUTSIDE
     */
    public static synchronized void evaluateAttendanceDecision(Context context, Location location, int transitionType, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        evaluateAttendanceDecision(context, location, "FUSED_CURRENT", transitionType, pendingResult, finishedFlag);
    }

    public static synchronized void evaluateAttendanceDecision(Context context, Location location, String locationProvider, int transitionType, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        if (context == null || location == null) {
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        double lat = location.getLatitude();
        double lng = location.getLongitude();
        float accuracy = location.getAccuracy();
        long eventTimestamp = (location.getTime() > 0) ? location.getTime() : System.currentTimeMillis();

        double distance = calculateDistance(lat, lng, OFFICE_LAT, OFFICE_LNG);
        saveLastLocationDiagnostic(context, lat, lng, accuracy, eventTimestamp, distance);

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String lastKnownState = prefs.getString(KEY_LAST_KNOWN_STATE, "UNKNOWN");
        long lastTransitionTime = prefs.getLong(KEY_LAST_TRANSITION_TIMESTAMP, 0);
        String currentCalculatedState = (distance <= AUTHORITATIVE_RADIUS_METERS) ? "INSIDE" : "OUTSIDE";

        Log.i(TAG, "[Authoritative Decision] Verified distance: " + String.format(Locale.US, "%.1f", distance) + "m (acc=" + accuracy + "m, provider=" + locationProvider + "). Current: " + currentCalculatedState + ", Prev: " + lastKnownState);

        // Date strings in Asia/Kolkata timezone
        Date eventDate = new Date(eventTimestamp);
        SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm a", Locale.US);
        sdfTime.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String timeStr = sdfTime.format(eventDate);

        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdfDate.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String dateStr = sdfDate.format(eventDate);

        String employeeId = prefs.getString("employee_id", "");
        String employeeName = prefs.getString("employee_name", "Employee");
        String townCity = prefs.getString("town_city", "Raniganj HQ");

        // -------------------------------------------------------------
        // ENTRY LOGIC: OUTSIDE -> INSIDE (distance <= 25.0m)
        // -------------------------------------------------------------
        if ("INSIDE".equals(currentCalculatedState)) {
            consecutiveInsideReadings++;
            consecutiveOutsideReadings = 0;

            JSONObject activeSession = getActiveSession(context);
            String sessionState = activeSession != null ? activeSession.optString("sessionState", "") : "";
            String checkoutStatus = activeSession != null ? activeSession.optString("checkoutStatus", "") : "";
            boolean isResolvedOutside = isExitPromptResolvedOutside(context);
            if ("PENDING_EXIT_CONFIRMATION".equalsIgnoreCase(sessionState) || 
                "PENDING_AUTO_CHECKOUT".equalsIgnoreCase(sessionState) || 
                "PENDING_AUTO_CHECKOUT".equalsIgnoreCase(checkoutStatus) || 
                STATE_EXIT_PROMPT_RESOLVED_OUTSIDE.equalsIgnoreCase(sessionState) || 
                isResolvedOutside) {
                Log.i(TAG, "=== NATIVE RETURN TO OFFICE DETECTED (Inside 25m) ===");
                processReturnTransition(context, location, "NATIVE_GEOFENCE_VERIFIED", pendingResult, finishedFlag);
                return;
            }

            boolean hasOpenSession = hasActiveSessionForDate(context, dateStr);
            boolean isSessionVerified = false;
            JSONObject curSession = getActiveSession(context);
            if (curSession != null && "VERIFIED".equals(curSession.optString("verificationStatus", ""))) {
                isSessionVerified = true;
            }

            // Debounce check: prevent rapid oscillation if transitioned within last 60s (applies when there is an existing verified session)
            long timeSinceLastTransition = eventTimestamp - lastTransitionTime;
            if (hasOpenSession && isSessionVerified && "OUTSIDE".equals(lastKnownState) && timeSinceLastTransition < MIN_TRANSITION_COOLDOWN_MS && lastTransitionTime > 0) {
                Log.i(TAG, "Debounce: Skipping rapid transition to INSIDE (elapsed: " + (timeSinceLastTransition / 1000) + "s < 60s)");
                safeFinishPendingResult(pendingResult, finishedFlag);
                return;
            }

            if (!"INSIDE".equals(lastKnownState) || !hasOpenSession || !isSessionVerified) {
                // ABSOLUTE RULE FOR AUTHORITATIVE CHECK-IN:
                // Verify fresh Fused Location fix <= 25m, non-synthetic, age <= 15s
                if (!isLocationTrustworthyForCheckIn(location)) {
                    Log.w(TAG, "[AUTO_CHECKIN_PENDING_VERIFICATION] evaluateAttendanceDecision rejected check-in: location not trustworthy for check-in (age > 15s or inaccurate, provider=" + locationProvider + ")");
                    safeFinishPendingResult(pendingResult, finishedFlag);
                    return;
                }
                if (distance > AUTHORITATIVE_RADIUS_METERS) {
                    Log.w(TAG, "[AUTO_CHECKIN_PENDING_VERIFICATION] evaluateAttendanceDecision rejected check-in: distance " + String.format(Locale.US, "%.1f", distance) + "m > " + AUTHORITATIVE_RADIUS_METERS + "m");
                    safeFinishPendingResult(pendingResult, finishedFlag);
                    return;
                }
                if ("HARDWARE_FALLBACK".equals(locationProvider) || (location.getProvider() != null && location.getProvider().toLowerCase(Locale.US).contains("hardware"))) {
                    Log.w(TAG, "[AUTO_CHECKIN_PENDING_VERIFICATION] evaluateAttendanceDecision rejected synthetic hardware fallback for check-in.");
                    safeFinishPendingResult(pendingResult, finishedFlag);
                    return;
                }
                if (location.getTime() <= 0) {
                    Log.w(TAG, "[AUTO_CHECKIN_PENDING_VERIFICATION] evaluateAttendanceDecision rejected check-in: missing location timestamp.");
                    safeFinishPendingResult(pendingResult, finishedFlag);
                    return;
                }

                Log.i(TAG, "=== NATIVE AUTHORITATIVE CHECK-IN TRIGGERED (Distance: " + String.format(Locale.US, "%.1f", distance) + "m <= 25m, Provider: " + locationProvider + ") ===");
                stopTemporaryAssistMonitoring(context, "check-in");
                logNativeAttendanceTimestampDiagnostic("CHECK_IN", "NATIVE_GEOFENCE", locationProvider, location, distance, employeeId);

                String eventId = "evt_native_CHECK_IN_" + employeeId + "_" + dateStr;

                long now = System.currentTimeMillis();
                long locationAgeMs = (location.getTime() > 0) ? (now - location.getTime()) : 0;
                long elapsedRealtimeAgeMs = 0;
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
                    long elapsedRealtimeNanos = location.getElapsedRealtimeNanos();
                    if (elapsedRealtimeNanos > 0) {
                        elapsedRealtimeAgeMs = (SystemClock.elapsedRealtimeNanos() - elapsedRealtimeNanos) / 1000000L;
                    }
                }
                SimpleDateFormat isoSdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
                isoSdf.setTimeZone(TimeZone.getTimeZone("UTC"));
                String verifiedAtIso = isoSdf.format(new Date(now));

                // Create persistent event
                JSONObject checkInEvent = new JSONObject();
                try {
                    checkInEvent.put("eventId", eventId);
                    checkInEvent.put("employeeId", employeeId);
                    checkInEvent.put("employeeName", employeeName);
                    checkInEvent.put("townCity", townCity);
                    checkInEvent.put("eventType", "CHECK_IN");
                    checkInEvent.put("transition", "ENTER");
                    checkInEvent.put("timestamp", eventTimestamp);
                    checkInEvent.put("eventTimestamp", eventTimestamp);
                    checkInEvent.put("createdAt", now);
                    checkInEvent.put("time", timeStr);
                    checkInEvent.put("date", dateStr);
                    checkInEvent.put("latitude", lat);
                    checkInEvent.put("longitude", lng);
                    checkInEvent.put("accuracy", accuracy);
                    checkInEvent.put("distanceFromOffice", distance);
                    checkInEvent.put("distance", distance);
                    checkInEvent.put("source", "native_geofence");
                    checkInEvent.put("locationProvider", locationProvider);
                    checkInEvent.put("schemaVersion", SCHEMA_VERSION);
                    checkInEvent.put("deviceId", getDeviceId(context));
                    checkInEvent.put("syncStatus", "PENDING");
                    checkInEvent.put("retryCount", 0);
                    checkInEvent.put("verificationStatus", "VERIFIED");
                    checkInEvent.put("verificationMethod", "FRESH_FUSED_LOCATION");
                    checkInEvent.put("authoritativeBoundaryMeters", 25);
                    checkInEvent.put("locationAgeMs", locationAgeMs);
                    checkInEvent.put("elapsedRealtimeAgeMs", elapsedRealtimeAgeMs);
                    checkInEvent.put("verifiedAt", verifiedAtIso);
                } catch (Exception e) {
                    Log.e(TAG, "Error constructing check-in JSON: " + e.getMessage());
                }

                // Update native persistent state
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString(KEY_LAST_KNOWN_STATE, "INSIDE");
                editor.putLong(KEY_LAST_CHECKIN_TIMESTAMP, eventTimestamp);
                editor.putLong(KEY_LAST_TRANSITION_TIMESTAMP, eventTimestamp);
                editor.putString(KEY_LAST_PROCESSED_EVENT_ID, eventId);
                editor.apply();

                // Persist session
                startActiveSession(context, employeeId, employeeName, townCity, dateStr, timeStr, "VERIFIED");

                // Add to unconsumed events queue for JS bridge
                addUnconsumedEvent(context, checkInEvent);

                // Add to offline sync queue (with deduplication)
                addEventToSyncQueue(context, checkInEvent);

                // Notify JS listeners if webview is active
                GeofencePlugin.notifyNativeCheckIn(checkInEvent);
                GeofencePlugin.notifyNativeTransition("ENTER", lat, lng, eventTimestamp);

                // Trigger autonomous background HTTP sync
                triggerBackgroundSync(context, pendingResult, finishedFlag);
                return;
            } else {
                Log.d(TAG, "Already verified inside office with active check-in. Duplicate check-in suppressed.");
            }
        }
        // -------------------------------------------------------------
        // EXIT LOGIC: INSIDE -> OUTSIDE (distance > 25.0m)
        // -------------------------------------------------------------
        else if ("OUTSIDE".equals(currentCalculatedState)) {
            consecutiveOutsideReadings++;
            consecutiveInsideReadings = 0;

            // GPS Accuracy & Noise Filter:
            // If distance is near the 25m boundary (25.1m to 40m), require at least 2 consecutive
            // outside readings to prevent a single noisy GPS spike from generating a false EXIT event.
            if (distance <= 40.0 && consecutiveOutsideReadings < 2 && transitionType != Geofence.GEOFENCE_TRANSITION_EXIT) {
                Log.i(TAG, "[GPS Noise Filter] Near-boundary distance: " + String.format(Locale.US, "%.1f", distance) + "m (reading " + consecutiveOutsideReadings + "/2). Awaiting confirmation before EXIT.");
                safeFinishPendingResult(pendingResult, finishedFlag);
                return;
            }

            processExitTransition(context, location, "NATIVE_GEOFENCE_VERIFIED", locationProvider, pendingResult, finishedFlag);
            return;
        }

        safeFinishPendingResult(pendingResult, finishedFlag);
    }

    /**
     * Authoritative 25m Geofence EXIT Candidate Fallback.
     *
     * Triggered when Google Play Services fires a primary 25m GEOFENCE_TRANSITION_EXIT
     * but subsequent high-accuracy Fused Location fix is unavailable, timed out, null,
     * or fails strict location validation.
     *
     * In accordance with Core Business Rules:
     * 1. 25m boundary is preserved (exit detected by Play Services 25m hardware geofence).
     * 2. This does NOT finalize checkout and does NOT set checkOutTime.
     * 3. It creates an explicit PENDING_AUTO_CHECKOUT candidate.
     * 4. Does NOT fabricate synthetic GPS coordinates.
     * 5. Uses triggerLocation.getTime() when available; otherwise event receipt time with
     *    timestampQuality = "GEOFENCE_EVENT_RECEIPT".
     * 6. Dispatches native notification to JS so CheckoutConfirmationModal appears.
     */
    public static synchronized void processGeofenceExitCandidate(Context context, Location triggerLocation, String source, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        if (context == null) {
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        double candDist = 25.0;
        if (triggerLocation != null && !Double.isNaN(triggerLocation.getLatitude()) && !Double.isNaN(triggerLocation.getLongitude())) {
            candDist = calculateDistance(triggerLocation.getLatitude(), triggerLocation.getLongitude(), OFFICE_LAT, OFFICE_LNG);
        }

        String currentState = getAttendanceState(context);
        boolean isAlreadyResolved = isExitPromptResolvedOutside(context);

        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Exit candidate received");
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Distance from office: " + String.format(Locale.US, "%.1f", candDist) + "m");
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Current attendance state: " + currentState);
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Exit prompt resolved outside: " + isAlreadyResolved);

        Log.i(TAG, "[NATIVE ATTENDANCE] EXIT EVENT RECEIVED");
        Log.i(TAG, "[NATIVE ATTENDANCE] CURRENT STATE=" + currentState);
        Log.i(TAG, "[NATIVE ATTENDANCE] EXIT PROMPT ALREADY RESOLVED=" + isAlreadyResolved);

        if (isAlreadyResolved || STATE_EXIT_PROMPT_RESOLVED_OUTSIDE.equalsIgnoreCase(currentState) || "RETURNING_TO_OFFICE".equalsIgnoreCase(currentState)) {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SUPPRESS_ALREADY_RESOLVED");
            Log.i(TAG, "[NATIVE ATTENDANCE] EXIT EVENT IGNORED - EXIT ALREADY RESOLVED OUTSIDE");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        JSONObject activeSession = getActiveSession(context);

        // Date strings in Asia/Kolkata timezone
        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdfDate.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String todayDateStr = sdfDate.format(new Date());

        // A. Verify there is an active attendance session for today's date
        if (activeSession == null) {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SUPPRESS_NO_SESSION");
            Log.w(TAG, "[EXIT_CANDIDATE_IGNORED] No active attendance session found. Exit candidate suppressed.");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        String sessionDate = activeSession.optString("date", "");
        if (!todayDateStr.equals(sessionDate)) {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SUPPRESS_DATE_MISMATCH");
            Log.w(TAG, "[EXIT_CANDIDATE_IGNORED] Active session date (" + sessionDate + ") does not match today (" + todayDateStr + "). Exit candidate suppressed.");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        // B. Verify today's attendance has a valid check-in
        String checkInTime = activeSession.optString("checkInTime", "");
        if (checkInTime == null || checkInTime.trim().isEmpty() || "--:--".equals(checkInTime) || "null".equalsIgnoreCase(checkInTime)) {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SUPPRESS_NO_CHECKIN");
            Log.w(TAG, "[EXIT_CANDIDATE_IGNORED] Active session has no valid check-in time ('" + checkInTime + "'). Exit candidate suppressed.");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        // C. Verify checkout is still missing (session is not already finalized/checked out)
        String sessionState = activeSession.optString("sessionState", "");
        String checkoutStatus = activeSession.optString("checkoutStatus", "");
        String checkOutTime = activeSession.optString("checkOutTime", "");
        boolean isAlreadyFinalized = "FINALIZED".equalsIgnoreCase(sessionState) ||
                                     "FINALIZED".equalsIgnoreCase(checkoutStatus) ||
                                     "COMPLETED".equalsIgnoreCase(checkoutStatus) ||
                                     (checkOutTime != null && !checkOutTime.trim().isEmpty() && !"null".equalsIgnoreCase(checkOutTime) && !"--:--".equals(checkOutTime));

        if (isAlreadyFinalized) {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SUPPRESS_ALREADY_FINALIZED");
            Log.i(TAG, "[EXIT_CANDIDATE_IGNORED] Session already finalized/checked out. Exit candidate suppressed.");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        if ("PENDING_EXIT_CONFIRMATION".equalsIgnoreCase(sessionState) || "PENDING_AUTO_CHECKOUT".equalsIgnoreCase(sessionState)) {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SUPPRESS_ALREADY_PENDING");
            Log.i(TAG, "[NATIVE ATTENDANCE] EXIT EVENT IGNORED - EXIT CONFIRMATION ALREADY PENDING");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SHOW_POPUP");
        Log.i(TAG, "[NATIVE ATTENDANCE] NEW AUTHORITATIVE EXIT AFTER RE-ENTRY");
        Log.i(TAG, "[NATIVE ATTENDANCE] SHOWING EXIT CONFIRMATION");

        // E. Best available geofence event timestamp (no System.currentTimeMillis() overwrite if trigger location has valid time)
        long eventTimestamp;
        String timestampQuality;
        if (triggerLocation != null && triggerLocation.getTime() > 0) {
            eventTimestamp = triggerLocation.getTime();
            timestampQuality = "TRIGGER_LOCATION_TIME";
        } else {
            eventTimestamp = System.currentTimeMillis();
            timestampQuality = "GEOFENCE_EVENT_RECEIPT";
        }

        Date eventDate = new Date(eventTimestamp);
        SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm a", Locale.US);
        sdfTime.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String timeStr = sdfTime.format(eventDate);

        SimpleDateFormat isoSdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        isoSdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        String isoTimestamp = isoSdf.format(eventDate);

        // Coordinates: ONLY use actual triggerLocation coordinates when available. DO NOT fabricate coordinates!
        Double lat = null;
        Double lng = null;
        Float accuracy = null;
        Double distance = null;

        if (triggerLocation != null && !Double.isNaN(triggerLocation.getLatitude()) && !Double.isNaN(triggerLocation.getLongitude())) {
            lat = triggerLocation.getLatitude();
            lng = triggerLocation.getLongitude();
            if (triggerLocation.hasAccuracy()) {
                accuracy = triggerLocation.getAccuracy();
            }
            distance = calculateDistance(lat, lng, OFFICE_LAT, OFFICE_LNG);
            saveLastLocationDiagnostic(context, lat, lng, accuracy != null ? accuracy : 25.0f, eventTimestamp, distance);
        }

        String employeeId = activeSession.optString("employeeId", prefs.getString("employee_id", ""));
        String employeeName = activeSession.optString("employeeName", prefs.getString("employee_name", "Employee"));
        String townCity = activeSession.optString("townCity", prefs.getString("town_city", "Raniganj HQ"));

        // D. Create unique EXIT event ID
        String uniqueExitEventId = "evt_native_EXIT_CANDIDATE_" + employeeId + "_" + sessionDate + "_" + eventTimestamp;
        Log.i(TAG, "=== NATIVE AUTHORITATIVE 25M GEOFENCE EXIT CANDIDATE: " + uniqueExitEventId + " at " + timeStr + " (quality=" + timestampQuality + ", source=" + source + ") ===");

        // F. Set pendingCheckoutConfirmation, pendingCheckoutEventId, currentState, checkoutStatus
        try {
            activeSession.put("pendingCheckoutConfirmation", true);
            activeSession.put("pendingCheckoutEventId", uniqueExitEventId);
            activeSession.put("currentState", "PENDING_AUTO_CHECKOUT");
            activeSession.put("checkoutStatus", "PENDING_AUTO_CHECKOUT");
            activeSession.put("sessionState", "PENDING_EXIT_CONFIRMATION");

            // G. Update active session with latest authoritative EXIT candidate
            activeSession.put("recordedExitTime", timeStr);
            activeSession.put("exitDetectedAt", isoTimestamp);
            activeSession.put("exitSource", source);
            activeSession.put("timestampQuality", timestampQuality);
        } catch (Exception e) {
            Log.e(TAG, "Error updating activeSession with exit candidate: " + e.getMessage());
        }

        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_ACTIVE_SESSION, activeSession.toString());
        editor.putString(KEY_LAST_KNOWN_STATE, "OUTSIDE");
        editor.putLong(KEY_LAST_CHECKOUT_TIMESTAMP, eventTimestamp);
        editor.putLong(KEY_LAST_TRANSITION_TIMESTAMP, eventTimestamp);
        editor.putString(KEY_LAST_PROCESSED_EVENT_ID, uniqueExitEventId);
        editor.putString(KEY_LAST_EXIT_TIME, timeStr);
        editor.putString(KEY_LAST_EXIT_DATE, sessionDate);
        editor.putString(KEY_LAST_EXIT_EMPLOYEE_ID, employeeId);
        editor.putString(KEY_LAST_EXIT_SESSION_ID, activeSession.optString("attendanceId", ""));
        editor.putBoolean("pendingCheckoutConfirmation", true);
        editor.putString("pendingCheckoutEventId", uniqueExitEventId);
        editor.putString("currentState", "PENDING_AUTO_CHECKOUT");
        editor.putString("checkoutStatus", "PENDING_AUTO_CHECKOUT");
        editor.apply();

        // Build exit candidate event
        JSONObject exitEvent = new JSONObject();
        try {
            exitEvent.put("eventId", uniqueExitEventId);
            exitEvent.put("employeeId", employeeId);
            exitEvent.put("employeeName", employeeName);
            exitEvent.put("townCity", townCity);
            exitEvent.put("eventType", "CHECK_OUT");
            exitEvent.put("transition", "EXIT");
            exitEvent.put("timestamp", eventTimestamp);
            exitEvent.put("eventTimestamp", eventTimestamp);
            exitEvent.put("exitTimestamp", eventTimestamp);
            exitEvent.put("createdAt", System.currentTimeMillis());
            exitEvent.put("time", timeStr);
            exitEvent.put("date", sessionDate);
            if (lat != null && lng != null) {
                exitEvent.put("latitude", lat.doubleValue());
                exitEvent.put("longitude", lng.doubleValue());
                if (accuracy != null) exitEvent.put("accuracy", accuracy.floatValue());
                if (distance != null) {
                    exitEvent.put("distanceFromOffice", distance.doubleValue());
                    exitEvent.put("distance", distance.doubleValue());
                }
            } else {
                exitEvent.put("latitude", JSONObject.NULL);
                exitEvent.put("longitude", JSONObject.NULL);
                exitEvent.put("accuracy", JSONObject.NULL);
                exitEvent.put("distanceFromOffice", JSONObject.NULL);
                exitEvent.put("distance", JSONObject.NULL);
            }
            exitEvent.put("source", source);
            exitEvent.put("locationProvider", triggerLocation != null ? triggerLocation.getProvider() : "GEOFENCE_HARDWARE");
            exitEvent.put("timestampQuality", timestampQuality);
            exitEvent.put("isExitCandidate", true);
            exitEvent.put("pendingCheckoutConfirmation", true);
            exitEvent.put("pendingCheckoutEventId", uniqueExitEventId);
            exitEvent.put("currentState", "PENDING_AUTO_CHECKOUT");
            exitEvent.put("checkoutStatus", "PENDING_AUTO_CHECKOUT");
            exitEvent.put("schemaVersion", SCHEMA_VERSION);
            exitEvent.put("deviceId", getDeviceId(context));
            exitEvent.put("syncStatus", "PENDING");
            exitEvent.put("retryCount", 0);
        } catch (Exception e) {
            Log.e(TAG, "Error constructing exit candidate JSON: " + e.getMessage());
        }

        // H. Add to KEY_EVENTS and KEY_SYNC_QUEUE
        addUnconsumedEvent(context, exitEvent);
        addEventToSyncQueue(context, exitEvent);

        // I. Notify JavaScript if WebView/Capacitor is active
        GeofencePlugin.notifyNativeCheckOut(exitEvent);

        // J. Also notify transition with actual coordinates if available (do not fabricate)
        if (lat != null && lng != null) {
            GeofencePlugin.notifyNativeTransition("EXIT", lat.doubleValue(), lng.doubleValue(), eventTimestamp);
        } else {
            GeofencePlugin.notifyNativeTransition("EXIT", Double.NaN, Double.NaN, eventTimestamp);
        }

        // K & L. Trigger background sync & finish PendingResult safely
        triggerBackgroundSync(context, pendingResult, finishedFlag);
    }

    public static synchronized void processExitTransition(Context context, Location location, String source, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        processExitTransition(context, location, source, "FUSED_CURRENT", pendingResult, finishedFlag);
    }

    public static synchronized void processExitTransition(Context context, Location location, String source, String locationProvider, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        if (context == null || location == null) {
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        double lat = location.getLatitude();
        double lng = location.getLongitude();
        float accuracy = location.getAccuracy();
        long eventTimestamp = (location.getTime() > 0) ? location.getTime() : System.currentTimeMillis();
        double distance = calculateDistance(lat, lng, OFFICE_LAT, OFFICE_LNG);

        String currentState = getAttendanceState(context);
        boolean isAlreadyResolved = isExitPromptResolvedOutside(context);

        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Exit candidate received");
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Distance from office: " + String.format(Locale.US, "%.1f", distance) + "m");
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Current attendance state: " + currentState);
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Exit prompt resolved outside: " + isAlreadyResolved);

        Log.i(TAG, "[NATIVE ATTENDANCE] EXIT EVENT RECEIVED");
        Log.i(TAG, "[NATIVE ATTENDANCE] CURRENT STATE=" + currentState);
        Log.i(TAG, "[NATIVE ATTENDANCE] EXIT PROMPT ALREADY RESOLVED=" + isAlreadyResolved);

        if (isAlreadyResolved || STATE_EXIT_PROMPT_RESOLVED_OUTSIDE.equalsIgnoreCase(currentState) || "RETURNING_TO_OFFICE".equalsIgnoreCase(currentState)) {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SUPPRESS_ALREADY_RESOLVED");
            Log.i(TAG, "[NATIVE ATTENDANCE] EXIT EVENT IGNORED - EXIT ALREADY RESOLVED OUTSIDE");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        JSONObject activeSession = getActiveSession(context);
        String sessionState = activeSession != null ? activeSession.optString("sessionState", "") : "";
        if ("PENDING_EXIT_CONFIRMATION".equalsIgnoreCase(sessionState) || "PENDING_AUTO_CHECKOUT".equalsIgnoreCase(sessionState)) {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SUPPRESS_ALREADY_PENDING");
            Log.i(TAG, "[NATIVE ATTENDANCE] EXIT EVENT IGNORED - EXIT CONFIRMATION ALREADY PENDING");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Evaluation result: SHOW_POPUP");
        Log.i(TAG, "[NATIVE ATTENDANCE] NEW AUTHORITATIVE EXIT AFTER RE-ENTRY");
        Log.i(TAG, "[NATIVE ATTENDANCE] SHOWING EXIT CONFIRMATION");

        saveLastLocationDiagnostic(context, lat, lng, accuracy, eventTimestamp, distance);

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String lastKnownState = prefs.getString(KEY_LAST_KNOWN_STATE, "UNKNOWN");
        long lastTransitionTime = prefs.getLong(KEY_LAST_TRANSITION_TIMESTAMP, 0);

        boolean hasOpenSession = (activeSession != null && 
                ("ACTIVE".equalsIgnoreCase(activeSession.optString("sessionState")) || 
                 "PENDING_EXIT_CONFIRMATION".equalsIgnoreCase(activeSession.optString("sessionState"))));
        boolean isSessionActive = (activeSession != null && "ACTIVE".equalsIgnoreCase(activeSession.optString("sessionState")));

        // Debounce check: only debounce repeated oscillations if NOT in a confirmed ACTIVE session (e.g. state is already OUTSIDE/PENDING)
        long timeSinceLastTransition = eventTimestamp - lastTransitionTime;
        if (!isSessionActive && "OUTSIDE".equals(lastKnownState) && distance <= 30.0 && timeSinceLastTransition < MIN_TRANSITION_COOLDOWN_MS && lastTransitionTime > 0) {
            Log.i(TAG, "Debounce: Skipping rapid oscillation near boundary to OUTSIDE (elapsed: " + (timeSinceLastTransition / 1000) + "s < 60s, dist=" + Math.round(distance) + "m)");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        String employeeId = prefs.getString("employee_id", "");
        if ((employeeId == null || employeeId.isEmpty()) && activeSession != null) {
            employeeId = activeSession.optString("employeeId", "");
        }

        if (!"INSIDE".equals(lastKnownState) && !hasOpenSession && (employeeId == null || employeeId.isEmpty())) {
            Log.d(TAG, "Already verified outside office with no active session or employee identity.");
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        consecutiveOutsideReadings = 0;
        Log.i(TAG, "=== NATIVE AUTHORITATIVE CHECK-OUT TRIGGERED (Distance: " + String.format(Locale.US, "%.1f", distance) + "m > 25m, Source: " + source + ", Provider: " + locationProvider + ") ===");
        stopTemporaryAssistMonitoring(context, "exit");
        logNativeAttendanceTimestampDiagnostic("CHECK_OUT", "NATIVE_GEOFENCE", locationProvider, location, distance, employeeId);

        // Date strings in Asia/Kolkata timezone
        Date eventDate = new Date(eventTimestamp);
        SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm a", Locale.US);
        sdfTime.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String timeStr = sdfTime.format(eventDate);

        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdfDate.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String dateStr = sdfDate.format(eventDate);

        String employeeName = prefs.getString("employee_name", "Employee");
        if ((employeeName == null || employeeName.isEmpty() || "Employee".equals(employeeName)) && activeSession != null) {
            employeeName = activeSession.optString("employeeName", "Employee");
        }
        String townCity = prefs.getString("town_city", "Raniganj HQ");
        if ((townCity == null || townCity.isEmpty() || "Raniganj HQ".equals(townCity)) && activeSession != null) {
            townCity = activeSession.optString("townCity", "Raniganj HQ");
        }

        String eventId = "evt_native_CHECK_OUT_" + employeeId + "_" + dateStr + "_" + eventTimestamp;

        JSONObject checkOutEvent = new JSONObject();
        try {
            checkOutEvent.put("eventId", eventId);
            checkOutEvent.put("employeeId", employeeId);
            checkOutEvent.put("employeeName", employeeName);
            checkOutEvent.put("townCity", townCity);
            checkOutEvent.put("eventType", "CHECK_OUT");
            checkOutEvent.put("transition", "EXIT");
            checkOutEvent.put("timestamp", eventTimestamp);
            checkOutEvent.put("eventTimestamp", eventTimestamp);
            checkOutEvent.put("exitTimestamp", eventTimestamp);
            checkOutEvent.put("createdAt", System.currentTimeMillis());
            checkOutEvent.put("time", timeStr);
            checkOutEvent.put("date", dateStr);
            checkOutEvent.put("latitude", lat);
            checkOutEvent.put("longitude", lng);
            checkOutEvent.put("accuracy", accuracy);
            checkOutEvent.put("distanceFromOffice", distance);
            checkOutEvent.put("distance", distance);
            checkOutEvent.put("source", "native_geofence");
            checkOutEvent.put("locationProvider", locationProvider);
            checkOutEvent.put("schemaVersion", SCHEMA_VERSION);
            checkOutEvent.put("deviceId", getDeviceId(context));
            checkOutEvent.put("syncStatus", "PENDING");
            checkOutEvent.put("retryCount", 0);
        } catch (Exception e) {
            Log.e(TAG, "Error constructing check-out JSON: " + e.getMessage());
        }

        // Update native persistent state
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_LAST_KNOWN_STATE, "OUTSIDE");
        editor.putLong(KEY_LAST_CHECKOUT_TIMESTAMP, eventTimestamp);
        editor.putLong(KEY_LAST_TRANSITION_TIMESTAMP, eventTimestamp);
        editor.putString(KEY_LAST_PROCESSED_EVENT_ID, eventId);
        editor.putString(KEY_LAST_EXIT_TIME, timeStr);
        editor.apply();

        // Update active session with immutable exit time
        recordExitEvent(context, location, source);

        // Add to unconsumed events queue for JS bridge
        addUnconsumedEvent(context, checkOutEvent);

        // Add to offline sync queue (with deduplication)
        addEventToSyncQueue(context, checkOutEvent);

        // Notify JS listeners if webview is active
        GeofencePlugin.notifyNativeCheckOut(checkOutEvent);
        GeofencePlugin.notifyNativeTransition("EXIT", lat, lng, eventTimestamp);

        // Trigger autonomous background HTTP sync
        triggerBackgroundSync(context, pendingResult, finishedFlag);
    }

    public static synchronized void processReturnTransition(Context context, Location location, String source, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        if (context == null || location == null) {
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }

        double lat = location.getLatitude();
        double lng = location.getLongitude();
        float accuracy = location.getAccuracy();
        long eventTimestamp = (location.getTime() > 0) ? location.getTime() : System.currentTimeMillis();
        double distance = calculateDistance(lat, lng, OFFICE_LAT, OFFICE_LNG);

        saveLastLocationDiagnostic(context, lat, lng, accuracy, eventTimestamp, distance);

        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        // Date strings in Asia/Kolkata timezone
        Date eventDate = new Date(eventTimestamp);
        SimpleDateFormat sdfTime = new SimpleDateFormat("hh:mm a", Locale.US);
        sdfTime.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String timeStr = sdfTime.format(eventDate);

        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        sdfDate.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
        String dateStr = sdfDate.format(eventDate);

        JSONObject activeSession = getActiveSession(context);
        String employeeId = prefs.getString("employee_id", "");
        if ((employeeId == null || employeeId.isEmpty()) && activeSession != null) {
            employeeId = activeSession.optString("employeeId", "");
        }
        String employeeName = prefs.getString("employee_name", "Employee");
        if ((employeeName == null || employeeName.isEmpty() || "Employee".equals(employeeName)) && activeSession != null) {
            employeeName = activeSession.optString("employeeName", "Employee");
        }
        String townCity = prefs.getString("town_city", "Raniganj HQ");
        if ((townCity == null || townCity.isEmpty() || "Raniganj HQ".equals(townCity)) && activeSession != null) {
            townCity = activeSession.optString("townCity", "Raniganj HQ");
        }

        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Confirmed re-entry to 25m detected -> re-arming exit detection");
        Log.i(TAG, "[GEOFENCE EXIT DEBUG] Exit state reset: EXIT_PROMPT_RESOLVED_OUTSIDE cleared");
        Log.i(TAG, "[NATIVE ATTENDANCE] AUTHORITATIVE RE-ENTRY CONFIRMED");
        Log.i(TAG, "[NATIVE ATTENDANCE] EXIT PROMPT RE-ARMED");
        Log.i(TAG, "=== NATIVE RETURN INSIDE 25m OFFICE GEOFENCE CONFIRMED (Cancelling Pending Exit via " + source + ") ===");
        stopTemporaryAssistMonitoring(context, "return");
        logNativeAttendanceTimestampDiagnostic("GEOFENCE_RETURN", "NATIVE_GEOFENCE", "FUSED_CURRENT", location, distance, employeeId);

        // 1. Restore session to ACTIVE and re-arm exit prompt
        try {
            String sessionStr = prefs.getString(KEY_ACTIVE_SESSION, null);
            if (sessionStr != null) {
                JSONObject session = new JSONObject(sessionStr);
                session.put("recordedExitTime", JSONObject.NULL);
                session.put("exitDetectedAt", JSONObject.NULL);
                session.put("exitSource", "NONE");
                session.put("sessionState", "ACTIVE");
                session.put("checkoutStatus", "ACTIVE");
                session.put("pendingCheckoutConfirmation", false);
                session.put("pendingCheckoutEventId", JSONObject.NULL);
                session.put("exitPromptResolvedOutside", false);

                SharedPreferences.Editor editor = prefs.edit();
                editor.putString(KEY_ACTIVE_SESSION, session.toString());
                editor.putString(KEY_LAST_KNOWN_STATE, "INSIDE");
                editor.putBoolean(KEY_EXIT_PROMPT_RESOLVED_OUTSIDE, false);
                editor.putLong(KEY_LAST_TRANSITION_TIMESTAMP, eventTimestamp);
                editor.putString(KEY_LAST_RETURN_TIME, timeStr);
                editor.remove(KEY_LAST_EXIT_TIME);
                editor.remove(KEY_LAST_EXIT_DATE);
                editor.remove(KEY_LAST_EXIT_EMPLOYEE_ID);
                editor.remove(KEY_LAST_EXIT_SESSION_ID);
                editor.putBoolean("pendingCheckoutConfirmation", false);
                editor.putString("pendingCheckoutEventId", null);
                editor.putString("currentState", "CHECKED_IN");
                editor.putString("sessionState", "ACTIVE");
                editor.putString("checkoutStatus", "ACTIVE");
                editor.apply();
            }
        } catch (Exception e) {
            Log.e(TAG, "Error updating activeSession on return: " + e.getMessage());
        }

        // 3. Create return event for backend & JS bridge
        String eventId = "evt_native_RETURN_" + employeeId + "_" + dateStr + "_" + eventTimestamp;
        JSONObject returnEvent = new JSONObject();
        try {
            returnEvent.put("eventId", eventId);
            returnEvent.put("employeeId", employeeId);
            returnEvent.put("employeeName", employeeName);
            returnEvent.put("townCity", townCity);
            returnEvent.put("eventType", "GEOFENCE_RETURN");
            returnEvent.put("transition", "ENTER");
            returnEvent.put("timestamp", eventTimestamp);
            returnEvent.put("eventTimestamp", eventTimestamp);
            returnEvent.put("createdAt", System.currentTimeMillis());
            returnEvent.put("time", timeStr);
            returnEvent.put("date", dateStr);
            returnEvent.put("latitude", lat);
            returnEvent.put("longitude", lng);
            returnEvent.put("accuracy", accuracy);
            returnEvent.put("distanceFromOffice", distance);
            returnEvent.put("distance", distance);
            returnEvent.put("source", "native_geofence");
            returnEvent.put("schemaVersion", SCHEMA_VERSION);
            returnEvent.put("deviceId", getDeviceId(context));
            returnEvent.put("syncStatus", "PENDING");
            returnEvent.put("retryCount", 0);
        } catch (Exception e) {
            Log.e(TAG, "Error constructing return JSON: " + e.getMessage());
        }

        // Add to unconsumed events & sync queue
        addUnconsumedEvent(context, returnEvent);
        addEventToSyncQueue(context, returnEvent);

        // Notify JS bridge
        GeofencePlugin.notifyNativeReturn(returnEvent);
        GeofencePlugin.notifyNativeTransition("ENTER", lat, lng, eventTimestamp);

        // Synchronize return to backend
        triggerBackgroundSync(context, pendingResult, finishedFlag);
    }

    private static String getDeviceId(Context context) {
        try {
            return android.provider.Settings.Secure.getString(context.getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
        } catch (Exception e) {
            return "UNKNOWN_DEVICE";
        }
    }

    private static boolean hasActiveSessionForDate(Context context, String dateStr) {
        JSONObject session = getActiveSession(context);
        if (session != null) {
            String sessDate = session.optString("date", "");
            String state = session.optString("sessionState", "");
            return dateStr.equals(sessDate) && ("ACTIVE".equalsIgnoreCase(state) || "PENDING_EXIT_CONFIRMATION".equalsIgnoreCase(state) || "PENDING_AUTO_CHECKOUT".equalsIgnoreCase(state));
        }
        return false;
    }

    private static synchronized void addUnconsumedEvent(Context context, JSONObject event) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String existing = prefs.getString(KEY_EVENTS, "[]");
            JSONArray arr = new JSONArray(existing);
            arr.put(event);
            prefs.edit().putString(KEY_EVENTS, arr.toString()).apply();
        } catch (Exception e) {
            Log.e(TAG, "Error adding unconsumed event: " + e.getMessage());
        }
    }

    /**
     * Queues an event for offline background sync with duplicate suppression.
     */
    private static synchronized void addEventToSyncQueue(Context context, JSONObject event) {
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String existing = prefs.getString(KEY_SYNC_QUEUE, "[]");
            JSONArray arr = new JSONArray(existing);

            String targetEventId = event.optString("eventId");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject item = arr.optJSONObject(i);
                if (item != null && targetEventId.equals(item.optString("eventId"))) {
                    Log.d(TAG, "Event already in sync queue: " + targetEventId + ". Skipping duplicate enqueue.");
                    return;
                }
            }

            arr.put(event);
            prefs.edit().putString(KEY_SYNC_QUEUE, arr.toString()).apply();
            Log.i(TAG, "Event queued for background sync: " + targetEventId);
        } catch (Exception e) {
            Log.e(TAG, "Error adding event to sync queue: " + e.getMessage());
        }
    }

    public static JSONArray getAndClearUnconsumedEvents(Context context) {
        if (context == null) return new JSONArray();
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String existingEventsJson = prefs.getString(KEY_EVENTS, "[]");
            JSONArray events = new JSONArray(existingEventsJson);
            prefs.edit().putString(KEY_EVENTS, "[]").apply();
            return events;
        } catch (Exception e) {
            Log.e(TAG, "Failed to get unconsumed events: " + e.getMessage(), e);
            return new JSONArray();
        }
    }

    public static void registerNetworkCallbackIfNecessary(Context context) {
        if (context == null || isNetworkCallbackRegistered) return;
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                cm.registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback() {
                    @Override
                    public void onAvailable(Network network) {
                        Log.i(TAG, "Network became available. Draining native offline attendance queue...");
                        triggerBackgroundSync(context);
                    }
                });
                isNetworkCallbackRegistered = true;
                Log.i(TAG, "Default network callback registered for background attendance sync.");
            }
        } catch (Exception e) {
            Log.e(TAG, "Failed to register network callback: " + e.getMessage(), e);
        }
    }

    public static void triggerBackgroundSync(Context context) {
        triggerBackgroundSync(context, null, null);
    }

    public static void triggerBackgroundSync(Context context, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        if (context == null) {
            safeFinishPendingResult(pendingResult, finishedFlag);
            return;
        }
        registerNetworkCallbackIfNecessary(context);

        executor.execute(() -> {
            synchronized (OfficeGeofenceHelper.class) {
                if (isSyncRunning) {
                    safeFinishPendingResult(pendingResult, finishedFlag);
                    return;
                }
                isSyncRunning = true;
            }
            try {
                performBackgroundSync(context, pendingResult, finishedFlag);
            } catch (Exception e) {
                Log.e(TAG, "Exception during background sync task:", e);
                safeFinishPendingResult(pendingResult, finishedFlag);
            } finally {
                synchronized (OfficeGeofenceHelper.class) {
                    isSyncRunning = false;
                }
            }
        });
    }

    private static void performBackgroundSync(Context context, BroadcastReceiver.PendingResult pendingResult, AtomicBoolean finishedFlag) {
        PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock wakeLock = null;
        if (pm != null) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "exfin:geofence_sync_lock");
            wakeLock.setReferenceCounted(false);
            try {
                wakeLock.acquire(15000); // 15 seconds max
            } catch (Exception ignored) {}
        }

        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String serverUrl = prefs.getString("server_url", null);
            if (serverUrl == null || serverUrl.trim().isEmpty() || serverUrl.contains("localhost") || serverUrl.contains("127.0.0.1")) {
                serverUrl = DEFAULT_SERVER_URL;
            }
            if (serverUrl == null || serverUrl.trim().isEmpty()) {
                Log.w(TAG, "Cannot sync: server_url is not configured in SharedPreferences.");
                return;
            }

            String queueStr = prefs.getString(KEY_SYNC_QUEUE, "[]");
            JSONArray queue;
            try {
                queue = new JSONArray(queueStr);
            } catch (Exception e) {
                Log.e(TAG, "Failed to parse sync queue: " + e.getMessage());
                return;
            }

            if (queue.length() == 0) {
                return;
            }

            Log.i(TAG, "Draining native offline sync queue: " + queue.length() + " pending events...");
            JSONArray remainingQueue = new JSONArray();

            for (int i = 0; i < queue.length(); i++) {
                JSONObject event = queue.optJSONObject(i);
                if (event == null) continue;

                String eventId = event.optString("eventId");
                String employeeId = event.optString("employeeId");
                String eventType = event.optString("eventType");
                long eventTimestamp = event.optLong("eventTimestamp", event.optLong("timestamp", System.currentTimeMillis()));

                JSONObject payload = new JSONObject();
                try {
                    payload.put("employeeId", employeeId);
                    payload.put("employeeName", event.optString("employeeName"));
                    payload.put("townCity", event.optString("townCity"));
                    payload.put("deviceId", event.optString("deviceId"));
                    payload.put("eventId", eventId);
                    payload.put("eventType", eventType);
                    payload.put("transition", event.optString("transition", eventType));
                    payload.put("distance", event.optDouble("distance", 25.0));
                    payload.put("distanceFromOffice", event.optDouble("distanceFromOffice", 25.0));
                    payload.put("source", "native_geofence");
                    payload.put("schemaVersion", SCHEMA_VERSION);
                    payload.put("latitude", event.optDouble("latitude", OFFICE_LAT));
                    payload.put("longitude", event.optDouble("longitude", OFFICE_LNG));
                    payload.put("accuracy", event.optDouble("accuracy", 20.0));

                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
                    sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
                    payload.put("timestamp", sdf.format(new Date(eventTimestamp)));
                } catch (Exception e) {
                    Log.e(TAG, "Failed to build payload for event " + eventId + ": " + e.getMessage());
                    remainingQueue.put(event);
                    continue;
                }

                boolean success = false;
                try {
                    URL url = new URL(serverUrl + "/api/median-background-location");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                    conn.setDoOutput(true);
                    conn.setConnectTimeout(10000);
                    conn.setReadTimeout(10000);

                    OutputStream os = conn.getOutputStream();
                    os.write(payload.toString().getBytes("UTF-8"));
                    os.close();

                    int code = conn.getResponseCode();
                    if (code == 200 || code == 201) {
                        success = true;
                        Log.i(TAG, "Successfully synced native event " + eventId + " to backend (HTTP " + code + ").");
                        prefs.edit().putLong(KEY_LAST_SYNC_TIME, System.currentTimeMillis()).apply();
                        GeofencePlugin.notifyNativeSync(eventId, true);
                    } else {
                        Log.w(TAG, "Backend returned HTTP " + code + " for event " + eventId);
                    }
                    conn.disconnect();
                } catch (Exception e) {
                    Log.w(TAG, "Network failure syncing event " + eventId + ": " + e.getMessage());
                }

                if (!success) {
                    try {
                        int retryCount = event.optInt("retryCount", 0);
                        event.put("retryCount", retryCount + 1);
                        event.put("syncStatus", "RETRY");
                    } catch (Exception ignored) {}
                    remainingQueue.put(event);
                }
            }

            prefs.edit().putString(KEY_SYNC_QUEUE, remainingQueue.toString()).apply();
        } catch (Exception e) {
            Log.e(TAG, "Exception in performBackgroundSync", e);
        } finally {
            if (wakeLock != null && wakeLock.isHeld()) {
                try {
                    wakeLock.release();
                } catch (Exception ignored) {}
            }
            safeFinishPendingResult(pendingResult, finishedFlag);
        }
    }

    public static synchronized void startActiveSession(Context context, String employeeId, String employeeName, String townCity, String date, String checkInTime) {
        startActiveSession(context, employeeId, employeeName, townCity, date, checkInTime, "VERIFIED");
    }

    public static synchronized void startActiveSession(Context context, String employeeId, String employeeName, String townCity, String date, String checkInTime, String verificationStatus) {
        if (context == null) return;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

            JSONObject session = new JSONObject();
            session.put("attendanceId", "att_" + employeeId + "_" + date);
            session.put("employeeId", employeeId);
            session.put("employeeName", employeeName);
            session.put("townCity", townCity != null ? townCity : "Raniganj HQ");
            session.put("date", date);
            session.put("checkInTime", checkInTime);
            session.put("attendanceMode", "OFFICE");
            session.put("officeLatitude", OFFICE_LAT);
            session.put("officeLongitude", OFFICE_LNG);
            session.put("geofenceRadius", AUTHORITATIVE_RADIUS_METERS);
            session.put("verificationStatus", verificationStatus != null ? verificationStatus : "VERIFIED");
            session.put("sessionState", "ACTIVE");
            session.put("checkoutStatus", "ACTIVE");
            session.put("currentState", "CHECKED_IN");
            session.put("lastKnownState", "INSIDE");
            session.put("recordedExitTime", JSONObject.NULL);
            session.put("exitDetectedAt", JSONObject.NULL);
            session.put("exitSource", "NONE");
            session.put("pendingCheckoutConfirmation", false);
            session.put("pendingCheckoutEventId", JSONObject.NULL);

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(KEY_ACTIVE_SESSION, session.toString());
            editor.putString("employee_id", employeeId);
            editor.putString("employee_name", employeeName);
            editor.putString("town_city", townCity != null ? townCity : "Raniganj HQ");
            editor.putString(KEY_LAST_KNOWN_STATE, "INSIDE");
            editor.putString("currentState", "CHECKED_IN");
            editor.putString("sessionState", "ACTIVE");
            editor.putString("checkoutStatus", "ACTIVE");
            editor.putBoolean("pendingCheckoutConfirmation", false);
            editor.remove("pendingCheckoutEventId");
            editor.remove(KEY_LAST_EXIT_TIME);
            editor.remove(KEY_LAST_EXIT_DATE);
            editor.remove(KEY_LAST_EXIT_EMPLOYEE_ID);
            editor.remove(KEY_LAST_EXIT_SESSION_ID);
            editor.remove(KEY_EXIT_PROMPT_RESOLVED_OUTSIDE);
            editor.putLong(KEY_LAST_CHECKIN_TIMESTAMP, System.currentTimeMillis());
            editor.putLong(KEY_LAST_TRANSITION_TIMESTAMP, System.currentTimeMillis());
            editor.apply();

            Log.i(TAG, "[NATIVE_SESSION_STARTED] Fresh active office session initialized for " + employeeId + " on " + date + " at " + checkInTime + ". All prior exit states strictly cleared.");

            stopTemporaryAssistAwareness();
            registerOfficeGeofence(context);
            OfficeLocationService.start(context);
        } catch (Exception e) {
            Log.e(TAG, "Failed to start native active session: " + e.getMessage(), e);
        }
    }

    public static synchronized void clearActiveSession(Context context) {
        if (context == null) return;
        try {
            stopTemporaryAssistAwareness();
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            String sessionStr = prefs.getString(KEY_ACTIVE_SESSION, null);
            if (sessionStr != null) {
                JSONObject session = new JSONObject(sessionStr);
                session.put("sessionState", "FINALIZED");
                session.put("checkoutStatus", "FINALIZED");
                editor.putString(KEY_ACTIVE_SESSION, session.toString());
            }
            editor.putString(KEY_LAST_KNOWN_STATE, "OUTSIDE");
            editor.remove(KEY_LAST_EXIT_TIME);
            editor.remove(KEY_LAST_EXIT_DATE);
            editor.remove(KEY_LAST_EXIT_EMPLOYEE_ID);
            editor.remove(KEY_LAST_EXIT_SESSION_ID);
            editor.putBoolean("pendingCheckoutConfirmation", false);
            editor.remove("pendingCheckoutEventId");
            editor.remove(KEY_EXIT_PROMPT_RESOLVED_OUTSIDE);
            editor.putString("currentState", "FINALIZED");
            editor.putString("sessionState", "FINALIZED");
            editor.putString("checkoutStatus", "FINALIZED");
            editor.putLong(KEY_LAST_TRANSITION_TIMESTAMP, System.currentTimeMillis());
            editor.apply();
            Log.i(TAG, "[NATIVE_SESSION_FINALIZED] Native active session cleared.");
            OfficeLocationService.stop(context);
        } catch (Exception e) {
            Log.e(TAG, "Failed to clear native active session: " + e.getMessage(), e);
        }
    }

    public static JSONObject getActiveSession(Context context) {
        if (context == null) return null;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String sessionStr = prefs.getString(KEY_ACTIVE_SESSION, null);
            if (sessionStr != null) {
                return new JSONObject(sessionStr);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error reading active session: " + e.getMessage(), e);
        }
        return null;
    }

    public static synchronized void recordExitEvent(Context context, Location location, String source) {
        if (context == null) return;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String sessionStr = prefs.getString(KEY_ACTIVE_SESSION, null);
            if (sessionStr == null) return;

            JSONObject session = new JSONObject(sessionStr);
            String sessionState = session.optString("sessionState", "ACTIVE");
            if (!"ACTIVE".equals(sessionState) && !"PENDING_EXIT_CONFIRMATION".equals(sessionState)) {
                return;
            }

            long eventTimestamp = (location != null && location.getTime() > 0) ? location.getTime() : System.currentTimeMillis();
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.US);
            sdf.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata"));
            String timeStr = sdf.format(new Date(eventTimestamp));

            SimpleDateFormat isoSdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
            isoSdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            String isoTimestamp = isoSdf.format(new Date(eventTimestamp));

            session.put("recordedExitTime", timeStr);
            session.put("exitDetectedAt", isoTimestamp);
            session.put("exitSource", source);
            session.put("sessionState", "PENDING_EXIT_CONFIRMATION");
            session.put("checkoutStatus", "PENDING_EXIT_CONFIRMATION");

            prefs.edit().putString(KEY_ACTIVE_SESSION, session.toString()).apply();
            Log.i(TAG, "[NATIVE_EXIT_RECORDED] Authoritative exit time captured: " + timeStr + " via " + source);
        } catch (Exception e) {
            Log.e(TAG, "Failed to record native exit event: " + e.getMessage(), e);
        }
    }

    public static synchronized void cancelPendingExit(Context context) {
        if (context == null) return;
        try {
            Log.i(TAG, "[GEOFENCE EXIT DEBUG] Stay Active pressed -> setting state to EXIT_PROMPT_RESOLVED_OUTSIDE");
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String sessionStr = prefs.getString(KEY_ACTIVE_SESSION, null);
            if (sessionStr == null) return;

            JSONObject session = new JSONObject(sessionStr);
            session.put("sessionState", STATE_EXIT_PROMPT_RESOLVED_OUTSIDE);
            session.put("exitPromptResolvedOutside", true);
            session.put("pendingCheckoutConfirmation", false);
            session.put("pendingCheckoutEventId", JSONObject.NULL);

            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(KEY_ACTIVE_SESSION, session.toString());
            editor.putBoolean(KEY_EXIT_PROMPT_RESOLVED_OUTSIDE, true);
            editor.putString(KEY_LAST_KNOWN_STATE, "OUTSIDE");
            editor.putString("sessionState", STATE_EXIT_PROMPT_RESOLVED_OUTSIDE);
            editor.putString("currentState", STATE_EXIT_PROMPT_RESOLVED_OUTSIDE);
            editor.putBoolean("pendingCheckoutConfirmation", false);
            editor.putString("pendingCheckoutEventId", null);
            editor.putLong(KEY_LAST_TRANSITION_TIMESTAMP, System.currentTimeMillis());
            editor.apply();
            Log.i(TAG, "[NATIVE_RETURN_CANCELLED] Stay Active / Return to office executed. Set state to EXIT_PROMPT_RESOLVED_OUTSIDE while preserving session.");
        } catch (Exception e) {
            Log.e(TAG, "Failed to cancel pending exit: " + e.getMessage(), e);
        }
    }

    public static void saveLastLocationDiagnostic(Context context, double lat, double lng, float accuracy, long timestamp, double distance) {
        if (context == null) return;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            JSONObject diag = new JSONObject();
            diag.put("latitude", lat);
            diag.put("longitude", lng);
            diag.put("accuracy", accuracy);
            diag.put("timestamp", timestamp);
            diag.put("distance", distance);
            prefs.edit().putString(KEY_LAST_LOCATION_DIAGNOSTIC, diag.toString()).apply();
        } catch (Exception e) {
            Log.w(TAG, "Failed to save last location diagnostic: " + e.getMessage());
        }
    }

    public static void saveLastNativeTrigger(Context context, long timestamp) {
        if (context == null) return;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putLong(KEY_LAST_NATIVE_TRIGGER, timestamp).apply();
        } catch (Exception e) {
            Log.w(TAG, "Failed to save last native trigger: " + e.getMessage());
        }
    }

    public static void recordNativeError(Context context, String error) {
        if (context == null) return;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            prefs.edit().putString(KEY_LAST_NATIVE_ERROR, error + " (" + new Date().toString() + ")").apply();
            GeofencePlugin.notifyNativeError(error);
        } catch (Exception e) {
            Log.w(TAG, "Failed to record native error: " + e.getMessage());
        }
    }

    public static JSONObject getDiagnosticState(Context context) {
        JSONObject res = new JSONObject();
        if (context == null) return res;
        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            boolean fineLocation = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            boolean bgLocation = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED;
            boolean geofenceRegistered = isGeofenceRegistered(context);
            boolean locationServiceRunning = OfficeLocationService.isRunning();

            res.put("nativeGeofenceRegistered", geofenceRegistered);
            res.put("locationPermission", fineLocation ? "GRANTED" : "DENIED");
            res.put("backgroundLocationPermission", bgLocation ? "GRANTED" : "DENIED");
            res.put("foregroundService", locationServiceRunning ? "RUNNING" : "STOPPED");
            res.put("lastKnownState", prefs.getString(KEY_LAST_KNOWN_STATE, "UNKNOWN"));
            res.put("authoritativeRadiusMeters", AUTHORITATIVE_RADIUS_METERS);
            res.put("wakeupTriggerRadiusMeters", WAKEUP_TRIGGER_RADIUS_METERS);
            res.put("assistRadiusMeters", ASSIST_RADIUS_METERS);

            boolean ignoringBatteryOptimizations = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    ignoringBatteryOptimizations = pm.isIgnoringBatteryOptimizations(context.getPackageName());
                }
            }
            res.put("batteryOptimizationState", ignoringBatteryOptimizations ? "OPTIMIZED_DISABLED" : "RESTRICTED");

            String activeSessionStr = prefs.getString(KEY_ACTIVE_SESSION, null);
            if (activeSessionStr != null) {
                res.put("activeSession", new JSONObject(activeSessionStr));
            } else {
                res.put("activeSession", JSONObject.NULL);
            }

            String diagStr = prefs.getString(KEY_LAST_LOCATION_DIAGNOSTIC, null);
            if (diagStr != null) {
                JSONObject locObj = new JSONObject(diagStr);
                res.put("lastVerifiedLocation", locObj);
                res.put("lastVerifiedDistance", locObj.optDouble("distance", 0.0));
            }

            String syncQueueStr = prefs.getString(KEY_SYNC_QUEUE, "[]");
            JSONArray queueArr = new JSONArray(syncQueueStr);
            res.put("pendingEventCount", queueArr.length());

            res.put("lastNativeTrigger", prefs.getLong(KEY_LAST_NATIVE_TRIGGER, 0));
            res.put("lastCheckInTimestamp", prefs.getLong(KEY_LAST_CHECKIN_TIMESTAMP, 0));
            res.put("lastCheckOutTimestamp", prefs.getLong(KEY_LAST_CHECKOUT_TIMESTAMP, 0));
            res.put("lastSyncTime", prefs.getLong(KEY_LAST_SYNC_TIME, 0));
            res.put("lastNativeError", prefs.getString(KEY_LAST_NATIVE_ERROR, "None"));
            res.put("lastExitTime", prefs.getString(KEY_LAST_EXIT_TIME, null));
            res.put("lastReturnTime", prefs.getString(KEY_LAST_RETURN_TIME, null));
        } catch (Exception e) {
            Log.e(TAG, "Error generating diagnostic state: " + e.getMessage(), e);
        }
        return res;
    }

    public static boolean isGeofenceRegistered(Context context) {
        if (context == null) return false;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_IS_REGISTERED, false);
    }

    public static void setGeofenceRegistered(Context context, boolean registered) {
        if (context == null) return;
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_IS_REGISTERED, registered).apply();
    }

    public static void ensureNativeAttendanceReady(Context context) {
        if (context == null) return;
        final Context appContext = context.getApplicationContext();
        try {
            SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putLong(KEY_LAST_REGISTRATION_ATTEMPT, System.currentTimeMillis());
            editor.apply();

            // 1. Register/re-register network callback
            registerNetworkCallbackIfNecessary(appContext);

            // 2. Register existing geofences
            registerOfficeGeofence(appContext);

            // 3. Trigger existing background sync
            triggerBackgroundSync(appContext);

            // 4. Record and update native readiness state
            boolean hasFineLocation = ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
            boolean hasBackgroundLocation = true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                hasBackgroundLocation = ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED;
            }
            boolean isRegistered = prefs.getBoolean(KEY_IS_REGISTERED, false);
            boolean ready = hasFineLocation && hasBackgroundLocation && isRegistered;
            editor.putBoolean(KEY_ENGINE_READY, ready);
            editor.apply();

            // 5. Diagnostics Logging (No secrets)
            Log.i(TAG, "[AUTO_ATTENDANCE_READY] Diagnostic Check:");
            Log.i(TAG, "[AUTO_ATTENDANCE_READY] - Schema version: " + SCHEMA_VERSION);
            Log.i(TAG, "[AUTO_ATTENDANCE_READY] - Employee ID present: " + (!prefs.getString("employee_id", "").isEmpty()));
            Log.i(TAG, "[AUTO_ATTENDANCE_READY] - Fine location permission: " + hasFineLocation);
            Log.i(TAG, "[AUTO_ATTENDANCE_READY] - Background location permission: " + hasBackgroundLocation);
            Log.i(TAG, "[AUTO_ATTENDANCE_READY] - Geofence registration status: " + isRegistered);
            Log.i(TAG, "[AUTO_ATTENDANCE_READY] - Native engine ready: " + ready);

        } catch (Exception e) {
            Log.e(TAG, "[AUTO_ATTENDANCE_READY] Exception during setup readiness check: " + e.getMessage(), e);
        }
    }

    public static void handleGeofenceAvailabilityError(Context context, String error) {
        if (context == null) return;
        final Context appContext = context.getApplicationContext();
        try {
            Log.e(TAG, "[NATIVE_ATTENDANCE] Geofence availability error reported: " + error);
            SharedPreferences prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putBoolean(KEY_ENGINE_READY, false);
            editor.putString(KEY_REGISTRATION_ERROR, error);
            editor.apply();

            setGeofenceRegistered(appContext, false);

            // Schedule safe retry after 10 seconds if not already scheduled
            if (isRetryScheduled.compareAndSet(false, true)) {
                Log.i(TAG, "[NATIVE_ATTENDANCE] Scheduling native geofence retry in 10 seconds...");
                scheduledExecutor.schedule(() -> {
                    try {
                        isRetryScheduled.set(false);
                        Log.i(TAG, "[NATIVE_ATTENDANCE] Retrying native geofence registration...");
                        ensureNativeAttendanceReady(appContext);
                    } catch (Exception e) {
                        Log.e(TAG, "[NATIVE_ATTENDANCE] Exception during geofence retry: " + e.getMessage(), e);
                    }
                }, 10, TimeUnit.SECONDS);
            }
        } catch (Exception e) {
            Log.e(TAG, "[NATIVE_ATTENDANCE] Exception handling geofence availability error: " + e.getMessage(), e);
        }
    }
}
