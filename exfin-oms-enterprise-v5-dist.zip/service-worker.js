// OFFLINE-FIRST CORE REQUIREMENT: APPLICATION STARTUP MUST NEVER DEPEND ON NETWORK CONNECTIVITY. NETWORK FAILURE MUST NEVER REDIRECT TO OR REPLACE THE NORMAL APPLICATION SHELL WITH AN OFFLINE PAGE.

const CACHE_NAME = 'exfin-oms-v15-indigo-v15';
const DYNAMIC_CACHE_NAME = 'exfin-oms-v15-dynamic-v15';

// Core Application Shell Assets (Injected during build by Vite plugin)
const PRECACHE_ASSETS = [
  "/",
  "/index.html",
  "/manifest.json",
  "/favicon.ico",
  "/assets/centralNotificationService-CrxSDYpA.js",
  "/assets/html2canvas.esm-QH1iLAAe.js",
  "/assets/index-B1nqagVl.js",
  "/assets/index-CJUmijnb.css",
  "/assets/index-CKPm0Mug.js",
  "/assets/index-CmaIwHuW.js",
  "/assets/index.es-DZ3OM8bg.js",
  "/assets/purify.es-DP5U8-sc.js",
  "/assets/web-0LGPSBku.js",
  "/assets/web-BXI71ae4.js",
  "/assets/web-DG2DfNom.js",
  "/assets/web-DGC5mHRi.js"
];

// Fallback Embedded App Shell HTML (Injected during build by Vite plugin)
let fallbackAppShellText = "<!-- OFFLINE-FIRST CORE REQUIREMENT: APPLICATION STARTUP MUST NEVER DEPEND ON NETWORK CONNECTIVITY. NETWORK FAILURE MUST NEVER REDIRECT TO OR REPLACE THE NORMAL APPLICATION SHELL WITH AN OFFLINE PAGE. -->\n<!doctype html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"UTF-8\" />\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no\" />\n    <meta name=\"theme-color\" content=\"#0F1025\" />\n    <link rel=\"manifest\" href=\"/manifest.json\" />\n    <title>Office Management System v6.0</title>\n    <script>\n      // Global Error and Resource Load Catcher for Live Diagnostics\n      (function() {\n        var errors = [];\n        function renderDiagnostics() {\n          var root = document.getElementById('root');\n          if (!root) {\n            // Retry when DOM is ready\n            window.addEventListener('DOMContentLoaded', renderDiagnostics);\n            return;\n          }\n          \n          var html = '<div style=\"min-height: 100vh; background-color: #0F1025; color: #FFFFFF; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; box-sizing: border-box;\">' +\n            '<div style=\"background-color: #1E1F41; border: 2px solid #EF4444; border-radius: 20px; padding: 40px; max-width: 800px; width: 100%; box-shadow: 0 10px 30px rgba(0,0,0,0.5); box-sizing: border-box;\">' +\n              '<h1 style=\"color: #EF4444; font-weight: 900; font-size: 24px; margin-top: 0; margin-bottom: 20px; text-transform: uppercase; letter-spacing: 2px;\">Exfin Startup Crash Diagnosis</h1>' +\n              '<p style=\"color: #B9B9D0; font-size: 15px; line-height: 1.6; margin-bottom: 25px;\">' +\n                'A fatal JavaScript error occurred during application startup. Below is the diagnostic report captured in real-time.' +\n              '</p>' +\n              '<div style=\"background-color: rgba(239,68,68,0.1); border: 1px solid rgba(239,68,68,0.3); border-radius: 12px; padding: 20px; margin-bottom: 25px; font-family: monospace; font-size: 13px; text-align: left; line-height: 1.6; color: #FCA5A5; overflow-x: auto; max-height: 350px;\">';\n          \n          errors.forEach(function(err, index) {\n            html += '<div style=\"margin-bottom: 15px; border-bottom: 1px solid rgba(239,68,68,0.2); padding-bottom: 15px;\">' +\n              '<strong>⚠️ Exception #' + (index + 1) + ':</strong> ' + (err.message || 'Unknown error') + '<br/>' +\n              '<strong>📂 Source:</strong> <span style=\"word-break: break-all; color: #F87171;\">' + (err.filename || 'Unknown source') + '</span>:' + (err.lineno || '?') + ':' + (err.colno || '?') + '<br/>';\n            if (err.stack) {\n              html += '<strong>🥞 Stack Trace:</strong><pre style=\"margin: 5px 0 0 0; font-size: 11px; color: #F87171; overflow-x: auto; white-space: pre-wrap; word-break: break-all; font-family: monospace;\">' + err.stack + '</pre>';\n            }\n            html += '</div>';\n          });\n          \n          html += '</div>' +\n              '<div style=\"display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;\">' +\n                '<button onclick=\"window.location.reload()\" style=\"background-image: linear-gradient(to right, #DC2626, #EF4444); color: white; border: none; padding: 12px 24px; border-radius: 12px; font-weight: bold; font-size: 13px; cursor: pointer; transition: opacity 0.2s;\">Force Reload</button>' +\n                '<button onclick=\"window.location.search = \\'?boottest=1\\'\" style=\"background-color: #312E81; border: 1px solid #4F46E5; color: #C7D2FE; padding: 12px 24px; border-radius: 12px; font-weight: bold; font-size: 13px; cursor: pointer;\">Run HTML Boot Test</button>' +\n                '<button onclick=\"window.location.search = \\'?boottest=2\\'\" style=\"background-color: #064E3B; border: 1px solid #059669; color: #A7F3D0; padding: 12px 24px; border-radius: 12px; font-weight: bold; font-size: 13px; cursor: pointer;\">Run Module Boot Test</button>' +\n              '</div>' +\n            '</div>' +\n          '</div>';\n          \n          root.innerHTML = html;\n        }\n\n        window.addEventListener('error', function(event) {\n          // Ignore the controlled STOP_RENDER boot tests\n          if (event.message && (event.message.indexOf('STOP_RENDER_BOOT_TEST') !== -1 || event.message.indexOf('STOP_RENDER_MODULE_BOOT_TEST') !== -1)) {\n            event.preventDefault();\n            return;\n          }\n          \n          // Intercept script/link load failures (network 404 or mime-type mismatch)\n          if (event.target && (event.target.tagName === 'SCRIPT' || event.target.tagName === 'LINK')) {\n            var srcUrl = event.target.src || event.target.href;\n            errors.push({\n              message: 'Failed to load static asset module. URL returned 404 or text/html instead of javascript/css.',\n              filename: srcUrl,\n              lineno: 0,\n              colno: 0\n            });\n            renderDiagnostics();\n            return;\n          }\n\n          errors.push({\n            message: event.message,\n            filename: event.filename,\n            lineno: event.lineno,\n            colno: event.colno,\n            stack: event.error ? event.error.stack : null\n          });\n          renderDiagnostics();\n        }, true); // Use capture to intercept script loading errors\n\n        window.addEventListener('unhandledrejection', function(event) {\n          var reason = event.reason || {};\n          if (reason.message && (reason.message.indexOf('STOP_RENDER_BOOT_TEST') !== -1 || reason.message.indexOf('STOP_RENDER_MODULE_BOOT_TEST') !== -1)) {\n            event.preventDefault();\n            return;\n          }\n          \n          errors.push({\n            message: 'Unhandled Promise Rejection: ' + (reason.message || reason.toString()),\n            filename: reason.fileName || 'Promise',\n            lineno: reason.lineNumber || 0,\n            colno: reason.columnNumber || 0,\n            stack: reason.stack || null\n          });\n          renderDiagnostics();\n        });\n      })();\n\n      window.__EXFIN_STARTUP_COUNT = (window.__EXFIN_STARTUP_COUNT || 0) + 1;\n      console.log('[OFFLINE-ROOT] JavaScript bundle executed, count:', window.__EXFIN_STARTUP_COUNT);\n      window.addEventListener('DOMContentLoaded', function() {\n        console.log('[OFFLINE-ROOT] DOMContentLoaded');\n      });\n\n      if ('serviceWorker' in navigator) {\n        navigator.serviceWorker.getRegistrations().then(function (registrations) {\n          for (var i = 0; i < registrations.length; i++) {\n            registrations[i].unregister().then(function (success) {\n              if (success) {\n                console.log('[SW-DIAGNOSTIC] Successfully unregistered stale service worker');\n              }\n            });\n          }\n        }).catch(function (err) {\n          console.warn('Failed to get service worker registrations:', err);\n        });\n      }\n    </script>\n    <script type=\"module\" crossorigin src=\"/assets/index-CKPm0Mug.js\"></script>\n    <link rel=\"stylesheet\" crossorigin href=\"/assets/index-CJUmijnb.css\">\n  </head>\n  <body>\n    <div id=\"root\"></div>\n    <script>\n      if (window.location.search.indexOf('boottest=1') !== -1) {\n        document.getElementById('root').innerHTML = `\n          <div style=\"min-height: 100vh; background-color: #0F1025; color: #FFFFFF; font-family: sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 20px; text-align: center;\">\n            <div style=\"background-color: #1E1F41; border: 1px solid #6366F1; border-radius: 20px; padding: 40px; max-width: 500px; width: 100%; box-shadow: 0 10px 30px rgba(0,0,0,0.5);\">\n              <h1 style=\"color: #6366F1; font-weight: 900; font-size: 24px; margin-bottom: 20px; text-transform: uppercase; letter-spacing: 2px;\">Exfin HTML Boot Test</h1>\n              <div style=\"background-color: rgba(99,102,241,0.1); border: 1px solid rgba(99,102,241,0.3); border-radius: 12px; padding: 20px; margin-bottom: 25px; font-family: monospace; font-size: 13px; text-align: left; line-height: 1.6; color: #818CF8;\">\n                <p style=\"margin: 0;\">🌐 URL: \\${window.location.href}</p>\n                <p style=\"margin: 5px 0 0 0;\">📱 UserAgent: \\${navigator.userAgent}</p>\n                <p style=\"margin: 5px 0 0 0;\">🕒 Time: \\${new Date().toISOString()}</p>\n                <p style=\"margin: 5px 0 0 0;\">⚙️ HTML Parse & Inline JS: ACTIVE & OK</p>\n              </div>\n              <p style=\"color: #B9B9D0; font-size: 14px; line-height: 1.5; margin-bottom: 30px;\">\n                This confirms your Cloudflare Worker is successfully serving index.html, the browser has parsed the page, and inline scripts are executing perfectly.\n              </p>\n              <button onclick=\"window.location.search = ''\" style=\"background-image: linear-gradient(to right, #4F46E5, #6366F1); color: white; border: none; padding: 12px 24px; border-radius: 12px; font-weight: bold; font-size: 13px; cursor: pointer; transition: opacity 0.2s;\">\n                Return to Normal App\n              </button>\n            </div>\n          </div>\n        `;\n        throw new Error('STOP_RENDER_BOOT_TEST');\n      }\n    </script>\n  </body>\n</html>\n";

// Helper to create synthetic HTML response
function createSyntheticAppShellResponse(htmlText) {
  const content = htmlText || '<!doctype html><html lang="en"><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no"/><title>EXFIN OMS ENTERPRISE v6.0</title></head><body><div id="root"></div></body></html>';
  return new Response(content, {
    status: 200,
    headers: {
      'Content-Type': 'text/html; charset=utf-8',
      'X-App-Shell-Source': 'ServiceWorker-OfflineFirst',
      'Cache-Control': 'public, max-age=31536000',
    },
  });
}

// Helper to search current active caches in CacheStorage for an asset
async function matchCurrentCache(requestOrUrl) {
  // 1. Try current primary cache
  const primaryCache = await caches.open(CACHE_NAME);
  const primaryMatch = await primaryCache.match(requestOrUrl, { ignoreSearch: true });
  if (primaryMatch) return primaryMatch;

  // 2. Try dynamic cache
  const dynamicCache = await caches.open(DYNAMIC_CACHE_NAME);
  const dynamicMatch = await dynamicCache.match(requestOrUrl, { ignoreSearch: true });
  if (dynamicMatch) return dynamicMatch;

  return null;
}

// Helper to validate if index.html is a valid app shell
async function isValidAppShell(response) {
  if (!response || (response.status !== 200 && response.status !== 304)) {
    return false;
  }
  const contentType = response.headers.get('content-type');
  if (!contentType || !contentType.includes('text/html')) {
    return false;
  }
  try {
    const clone = response.clone();
    const text = await clone.text();
    // A valid app shell must contain id="root" or id='root'
    if (!text.includes('id="root"') && !text.includes("id='root'")) {
      return false;
    }
    // Do not cache Cloudflare error pages or other standard error pages
    if (text.includes('cf-error-details') || text.includes('Cloudflare') || text.includes('error-code') || text.includes('Attention Required!')) {
      return false;
    }
    return true;
  } catch (err) {
    console.error('[SW] Error validating app shell:', err);
    return false;
  }
}

// Helper to handle recovery when a critical hashed JS asset fails to load
async function handleCriticalAssetFailure() {
  console.warn('[SW] Critical JS asset missing or corrupt. Initiating recovery...');
  try {
    const cache = await caches.open(CACHE_NAME);
    // 1. Invalidate stale cache
    await cache.delete('/index.html');
    await cache.delete('/');
    
    // 2. Try to fetch the newest index.html from network
    const netRes = await fetch('/index.html', { cache: 'no-cache' });
    if (netRes && (netRes.status === 200 || netRes.status === 304)) {
      const isValid = await isValidAppShell(netRes);
      if (isValid) {
        // Cache the new valid shell
        await cache.put('/index.html', netRes.clone());
        await cache.put('/', netRes);
        console.log('[SW] Successfully fetched and cached new application shell during recovery.');
      }
    }
  } catch (err) {
    console.error('[SW] Failed to fetch new application shell during recovery:', err);
  }
  
  // Return a controlled recovery script that reloads the app at most once.
  const recoveryJs = `
    (function() {
      console.warn('[EXFIN recovery] Stale JS asset detected. Initiating single-time recovery reload...');
      try {
        var attempts = parseInt(window.sessionStorage.getItem('exfin_recovery_attempts') || '0', 10);
        if (attempts < 1) {
          window.sessionStorage.setItem('exfin_recovery_attempts', (attempts + 1).toString());
          window.location.reload();
        } else {
          console.error('[EXFIN recovery] Recovery reload already attempted once. Aborting to prevent infinite loop.');
        }
      } catch (e) {
        console.error('[EXFIN recovery] Error during recovery check:', e);
      }
    })();
  `;
  return new Response(recoveryJs, {
    status: 200,
    headers: { 'Content-Type': 'application/javascript; charset=utf-8' }
  });
}

// Install Event: Precache Application Shell & Assets safely before activating
self.addEventListener('install', (event) => {
  event.waitUntil(
    (async () => {
      console.log('[SW] Pre-caching core application shell:', CACHE_NAME);
      const cache = await caches.open(CACHE_NAME);

      // We MUST fetch all PRECACHE_ASSETS successfully to consider the install successful.
      // If we are offline during install, we want it to FAIL so the previous working SW and cache are kept.
      const fetchPromises = PRECACHE_ASSETS.map(async (assetUrl) => {
        const response = await fetch(assetUrl, { cache: 'no-cache' });
        if (!response || (response.status !== 200 && response.status !== 304 && response.status !== 0)) {
          throw new Error('Failed to fetch ' + assetUrl);
        }
        await cache.put(assetUrl, response);
      });
      
      await Promise.all(fetchPromises);

      // Extract and cache any discovered assets from runtime index.html if possible
      try {
        const indexResponse = await cache.match('/index.html');
        if (indexResponse) {
          const indexHtmlText = await indexResponse.clone().text();
          if (indexHtmlText) {
            fallbackAppShellText = indexHtmlText;
          }
          
          const assetUrls = new Set();
          const scriptMatches = indexHtmlText.matchAll(/src=["'](\/assets\/[^"']+)["']/g);
          for (const match of scriptMatches) {
            assetUrls.add(match[1]);
          }
          const cssMatches = indexHtmlText.matchAll(/href=["'](\/assets\/[^"']+)["']/g);
          for (const match of cssMatches) {
            assetUrls.add(match[1]);
          }
          
          if (assetUrls.size > 0) {
            const dynamicFetchPromises = Array.from(assetUrls).map(async (url) => {
              const assetRes = await fetch(url, { cache: 'no-cache' });
              if (assetRes && (assetRes.status === 200 || assetRes.status === 304 || assetRes.status === 0)) {
                await cache.put(url, assetRes);
              } else {
                throw new Error('Failed to fetch dynamic asset ' + url);
              }
            });
            await Promise.all(dynamicFetchPromises);
          }
        }
      } catch (err) {
        console.warn('[SW] Runtime asset discovery failed, failing install:', err);
        throw err;
      }

      console.log('[SW] Successfully precached all assets.');
      
      // Skip waiting immediately to activate new shell ONLY when all assets are successfully fetched
      await self.skipWaiting();
    })()
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      // 1. Claim all open windows / WebViews immediately
      await self.clients.claim();
      console.log('[SW] Activated & claimed clients for', CACHE_NAME);

      // 2. Safe cache retirement: keep at least current & dynamic caches
      // and only delete very old caches after verifying primary cache has index.html
      const cacheNames = await caches.keys();
      const primaryCache = await caches.open(CACHE_NAME);
      const hasIndexHtml = await primaryCache.match('/index.html');

      if (hasIndexHtml) {
        // Delete all obsolete caches when new version is ready with index.html
        const oldCaches = cacheNames.filter(
          (cName) => cName !== CACHE_NAME && cName !== DYNAMIC_CACHE_NAME && cName.startsWith('exfin-oms-')
        );
        
        await Promise.all(
          oldCaches.map((cName) => {
            console.log('[SW] Retiring obsolete cache version:', cName);
            return caches.delete(cName);
          })
        );
      }
    })()
  );
});

// Fetch Event: Routing & Caching Strategy
self.addEventListener('fetch', (event) => {
  const { request } = event;

  if (request.method !== 'GET') {
    return;
  }

  const url = new URL(request.url);

  // Exclude internal dev requests
  if (
    url.pathname.startsWith('/src/') ||
    url.pathname.startsWith('/@') ||
    url.search.includes('t=')
  ) {
    return;
  }

  // EXCLUSIONS — NEVER INTERFERE WITH SENSITIVE API / FIRESTORE / AUTH / REVERSE GEOCODING / DOWNLOADS
  if (
    url.pathname.includes('/api/') ||
    url.pathname.includes('/downloads/') ||
    url.pathname.endsWith('.apk') ||
    url.hostname.includes('firebase') ||
    url.hostname.includes('firestore') ||
    url.hostname.includes('googleapis') ||
    url.hostname.includes('securetoken') ||
    url.hostname.includes('identitytoolkit') ||
    url.hostname.includes('openstreetmap') ||
    url.hostname.includes('bigdatacloud') ||
    url.pathname.includes('/auth/')
  ) {
    return;
  }

  // NAVIGATION REQUESTS (SPA Routes: /, /attendance, /planner, /expenses, /leave, /profile, /admin-portal, /x7Kp9, etc.)
  if (request.mode === 'navigate' || (request.headers.get('accept') && request.headers.get('accept').includes('text/html'))) {
    event.respondWith(
      (async () => {
        // ONLINE: Try the network first to fetch current index.html
        try {
          const networkResponse = await fetch(request);
          if (networkResponse) {
            const isValid = await isValidAppShell(networkResponse);
            if (isValid) {
              const responseToCache = networkResponse.clone();
              const cache = await caches.open(CACHE_NAME);
              await cache.put('/index.html', responseToCache.clone());
              await cache.put('/', responseToCache);
              return networkResponse;
            }
          }
        } catch (networkErr) {
          console.warn('[SW] Navigation network fetch failed, falling back to cached shell:', networkErr);
        }

        // OFFLINE: If network fails, serve last known-good cached index.html
        const cachedHtml = await matchCurrentCache('/index.html') || await matchCurrentCache('/');
        if (cachedHtml) {
          return cachedHtml;
        }

        // Absolute Fallback: Embedded application shell (NEVER fail or throw)
        if (fallbackAppShellText) {
          return createSyntheticAppShellResponse(fallbackAppShellText);
        }

        return createSyntheticAppShellResponse('');
      })()
    );
    return;
  }

  // STATIC APPLICATION ASSETS (JS chunks, CSS, images, icons, fonts, manifest)
  // CACHE-FIRST WITH MULTI-CACHE FALLBACK
  const isStaticAsset =
    url.pathname.startsWith('/assets/') ||
    url.pathname.startsWith('/images/') ||
    url.pathname.startsWith('/sounds/') ||
    url.pathname.endsWith('.js') ||
    url.pathname.endsWith('.css') ||
    url.pathname.endsWith('.png') ||
    url.pathname.endsWith('.jpg') ||
    url.pathname.endsWith('.jpeg') ||
    url.pathname.endsWith('.svg') ||
    url.pathname.endsWith('.ico') ||
    url.pathname.endsWith('.woff2') ||
    url.pathname === '/manifest.json' ||
    url.pathname === '/favicon.ico';

  if (isStaticAsset) {
    event.respondWith(
      (async () => {
        // 1. Try cache match first across current active caches
        const cachedResponse = await matchCurrentCache(request) || await matchCurrentCache(url.pathname);
        if (cachedResponse) {
          return cachedResponse;
        }

        // 2. Fetch from network if not in cache
        try {
          const response = await fetch(request);
          if (response) {
            const contentType = response.headers.get('content-type') || '';
            const isHtmlForJsCss = (url.pathname.endsWith('.js') || url.pathname.endsWith('.css')) && contentType.includes('text/html');

            if (response.status === 200 && !isHtmlForJsCss) {
              const responseToCache = response.clone();
              const cache = await caches.open(CACHE_NAME);
              await cache.put(request, responseToCache);
              return response;
            }

            // Treat 404 or HTML content for JS/CSS as a missing/stale asset
            if (response.status === 404 || isHtmlForJsCss) {
              if (url.pathname.endsWith('.js')) {
                // If it's HTML, it's extremely likely a captive portal or offline proxy intercept.
                // Do not initiate a destructive reload loop. Just fail gracefully.
                console.warn('[SW] JS asset 404 or returned HTML (likely offline proxy/captive portal). Returning warning fallback.');
                return new Response('console.warn("JS asset load failed due to 404 or HTML intercept");', {
                  status: 200,
                  headers: { 'Content-Type': 'application/javascript' }
                });
              }
            }
          }
          return response;
        } catch (fetchErr) {
          // If network fetch failed (offline/DNS error) and we don't have the asset cached
          if (url.pathname.endsWith('.js')) {
            console.warn('[SW] Network error fetching JS asset (likely offline). Returning warning fallback.');
            return new Response('console.warn("JS asset load failed due to network error");', {
              status: 200,
              headers: { 'Content-Type': 'application/javascript' }
            });
          }

          // 3. Fallback: match by pathname without query params
          const pathnameMatch = await matchCurrentCache(url.pathname);
          if (pathnameMatch) {
            return pathnameMatch;
          }

          // 4. Benign fallbacks for non-fatal assets to avoid throwing in WebView
          if (url.pathname.endsWith('.css')) {
            return new Response('/* offline fallback css */', {
              status: 200,
              headers: { 'Content-Type': 'text/css' }
            });
          }
          if (url.pathname.endsWith('.svg') || url.pathname.endsWith('.png') || url.pathname.endsWith('.ico')) {
            return new Response('', {
              status: 200,
              headers: { 'Content-Type': 'image/svg+xml' }
            });
          }

          throw fetchErr;
        }
      })()
    );
    return;
  }
});

