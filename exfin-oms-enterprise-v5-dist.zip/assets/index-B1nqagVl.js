import{r as i}from"./index-CKPm0Mug.js";const t=i("PushNotifications",{});export{t as PushNotifications};
